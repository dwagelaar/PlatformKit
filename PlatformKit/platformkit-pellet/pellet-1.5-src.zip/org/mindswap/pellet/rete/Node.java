package org.mindswap.pellet.rete;


import java.util.List;
import java.util.Map;

public class Node {

	public List vars;
	public List svars;
	public Map ind;
	
	public Node() {
		//ind = new HashMap();
	}

	
}
