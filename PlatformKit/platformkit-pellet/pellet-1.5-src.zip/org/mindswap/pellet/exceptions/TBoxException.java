/*
 * Created on Oct 9, 2005
 */
package org.mindswap.pellet.exceptions;


public class TBoxException extends Exception {
	public TBoxException() {
		super();
	}
	public TBoxException(String e) {
		super(e);
	}
}