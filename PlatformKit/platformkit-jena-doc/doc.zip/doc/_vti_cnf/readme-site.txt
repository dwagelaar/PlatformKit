vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|04 Feb 2004 15:39:55 -0000
vti_extenderversion:SR|6.0.2.6353
vti_cacheddtm:TX|04 Feb 2004 15:39:55 -0000
vti_filesize:IR|2363
vti_backlinkinfo:VX|
