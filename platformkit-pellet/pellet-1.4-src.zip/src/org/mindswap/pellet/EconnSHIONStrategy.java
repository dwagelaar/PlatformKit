/*
 * Created on Aug 29, 2004
 */
package org.mindswap.pellet;


/**
 * @author Bernardo Cuenca
 */
public class EconnSHIONStrategy extends PECSHIONStrategy {
    /**
     * @param abox
     * @param blocking
     */
    public EconnSHIONStrategy(ABox abox) {
        super( abox );
        blocking = new EconnDoubleBlocking( abox );
    }
    
    boolean supportsPseudoModelCompletion() {
        return false;
    }    

    class FilteredIterator extends IndividualIterator {
        /**
         * @param abox
         */
        private String ontology;

        boolean needToApplyRules;

        FilteredIterator(String ont) {
            super(abox, false);
            ontology = ont;
            needToApplyRules = false;
            findNext();
        }

        protected void findNext() {
            for(; index < stop; index++) {
                if((nodes.get(nodeList.get(index)) instanceof Individual)) {
                    Individual ind = (Individual) nodes.get(nodeList.get(index));
                    String ont1 = ind.getOntology();
                    if((ont1.equals(ontology)) || (!ont1.equals(ontology) && !ind.isRoot())) break;
                }
            }
        }
    }//End Class

    ABox complete() {
        while(!abox.isComplete() && !abox.isClosed()) {

            while(abox.changed) {
                abox.changed = false;

                if( log.isDebugEnabled() ) {
                    log.debug("Branch: " + abox.getBranch() + ", Depth: " + abox.treeDepth
                        + ", Size: " + abox.getNodes().size());
                    printBlocked();
                    abox.printTree();
                    abox.validate();
                }
                //Here optimization on separating individuals in KB

                IndividualIterator i = abox.getIndIterator();
                if(PelletOptions.USE_OPTIMIZEDINDIVIDUALS == true) {
                    if(((EconnectedKB) abox.getKB()).getCheckAll() == false) {
                        String ont2 = abox.getKB().getOntology();
                        IndividualIterator it = new FilteredIterator(ont2);
                        i = it;
                    }
                }
                timers.startTimer("applyUnfoldingRule");
                applyUnfoldingRule(i);
                timers.stopTimer("applyUnfoldingRule");
                if(abox.isClosed()) break;

                timers.startTimer("applyDisjunctionRule");
                applyDisjunctionRule(i);
                timers.stopTimer("applyDisjunctionRule");
                if(abox.isClosed()) break;

                timers.startTimer("applySomeValuesRule");
                applySomeValuesRule(i);
                timers.stopTimer("applySomeValuesRule");
                if(abox.isClosed()) break;

                timers.startTimer("applyMinRule");
                applyMinRule(i);
                timers.stopTimer("applyMinRule");
                // min rule cannot introduce a clash

                applyNominalRule(i);
                if(abox.isClosed()) break;

                timers.startTimer("applyMaxRule");
                applyMaxRule(i);
                timers.stopTimer("applyMaxRule");
                if(abox.isClosed()) break;

//                if(hasClash()) break;
            }

            if(abox.isClosed()) {
                if( log.isDebugEnabled() ) 
                    log.debug( "Clash at Branch (" + abox.getBranch() + ") " + abox.getClash() );

                if(backtrack())
                    abox.setClash(null);
                else
                    abox.setComplete(true);
            }
            else
                abox.setComplete(true);
        }//End while

        return abox;
    }
}