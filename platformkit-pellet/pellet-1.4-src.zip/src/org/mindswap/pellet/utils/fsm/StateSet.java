/*
 * Created on Oct 20, 2006
 */
package org.mindswap.pellet.utils.fsm;

import java.util.HashSet;
import java.util.Iterator;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Clark & Parsia, LLC. <http://www.clarkparsia.com></p>
 *
 * @author Evren sirin
 */
public class StateSet {
    private HashSet set = new HashSet();

    public StateSet() {
    }

    public void clear() {
        set.clear();
    }
    
    public Iterator iterator() {
        return set.iterator();
    }
    
    public boolean add( State s ) {
        return set.add( s );
    }
    
    public void addAll( StateSet stateSet ) {
        set.addAll( stateSet.set );
    }
    
    public boolean contains( State s ) {
        return set.contains( s );
    }
    
    public boolean remove( State s ) {
        return set.remove( s );
    }
    
    public void removeAll( StateSet stateSet ) {
        set.removeAll( stateSet.set );
    }
    
    public int size() {
        return set.size();
    }
    
    public int hashCode() {
        return set.hashCode();
    }
    
    public boolean equals( Object o ) {
        if( o == this )
            return true;
        
        if( !(o instanceof StateSet) )
            return false;
            
        return set.equals( ((StateSet) o).set );
    }
    
    // ---------------------------------------------------
    // clear flags of all states in set

    public void clearInfo() {
        Iterator i = iterator();
        while( i.hasNext() ) {
            State st = (State) i.next();
            st.marked = false;
            st.partition_num = 0;
        }
    }

    // ---------------------------------------------------
    // sets partition number of all states in set

    public void setPartition( int num ) {
        Iterator i = iterator();
        while( i.hasNext() ) {
            State st = (State) i.next();
            st.partition_num = num;
        }
    }

    // ---------------------------------------------------
    // intersect - return obj in both sets

    StateSet intersect( StateSet ss ) {
        StateSet result = new StateSet();
        Iterator i = iterator();
        while( i.hasNext() ) {
            State st = (State) i.next();
            if( ss.contains( st ) )
                result.add( st );
        }
        return result;
    }

    // ---------------------------------------------------
    // minus - return objs not in second set

    StateSet minus( StateSet ss ) {
        StateSet result = new StateSet();
        Iterator i = iterator();
        while( i.hasNext() ) {
            State st = (State) i.next();
            if( !ss.contains( st ) )
                result.add( st );
        }
        return result;
    }
    
    public String toString() {
        return set.toString();
    }
}
