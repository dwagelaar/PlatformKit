// The MIT License
//
// Copyright (c) 2003 Ron Alford, Mike Grove, Bijan Parsia, Evren Sirin
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

/*
 * Created on Aug 29, 2004
 */
package org.mindswap.pellet;

import java.util.List;

import org.mindswap.pellet.exceptions.InternalReasonerException;

/**
 * @author Evren Sirin
 */
public class PECSHIONStrategy extends CompletionStrategy {
    /**
     * @param abox
     * @param blocking
     */

    public PECSHIONStrategy(ABox abox) {
        super(abox, new PECDoubleBlocking(abox));
    }    
    
    boolean supportsPseudoModelCompletion() {
        return false;
    }        

    class FilteredIterator extends IndividualIterator {
        /**
         * @param abox
         */
        private String ontology;

        boolean needToApplyRules;

        FilteredIterator(String ont) {
            super(abox, false);
            ontology = ont;
            needToApplyRules = false;
            findNext();
        }

        protected void findNext() {
            for(; index < stop; index++) {
                if((nodes.get(nodeList.get(index)) instanceof Individual)) {
                    Individual ind = (Individual) nodes.get(nodeList.get(index));
                    String ont1 = ind.getOntology();
                    if(ont1.equals(ontology))
                        break;
                    else {
                        if(((EconnectedKB) abox.getKB()).getEconnExpressivity().hasNominal(ont1))
                            break;
                        else {
                            if(!ind.isRoot()) break;
                        }
                    }
                    //if((ont1.equals(ontology) )||(!ont1.equals(ontology)&&
                    // !ind.isRoot()
                    // &&!((EconnectedKB)abox.getKB()).getEconnExpressivity().hasNominal(ont1))
                    // )
                    //     break;
                }
            }
        }
    }//End Class

    /**
     * Apply the unfolding rule to every concept in every node.
     *  
     */
    protected void applyUnfoldingRule(IndividualIterator i) {
        i.reset();
        while( i.hasNext() ) {
            Individual node = (Individual) i.next();

            unfoldingMap = ((EconnectedKB) abox.getKB()).getTBox(node.getOntology()).getUnfoldingMap();
            
            applyUnfoldingRule( node );

            if( abox.isClosed() ) return;
        }        
    }

    protected boolean backtrack() {
        boolean branchFound = false;

        while(!branchFound) {
            int lastBranch = abox.getClash().depends.max();

            if(lastBranch <= 0)
                return false;
            else if(lastBranch > abox.getBranches().size())
                throw new InternalReasonerException("Backtrack: Trying to backtrack to branch "
                    + lastBranch + " but has only " + abox.getBranches().size() + " branches");

            List branches = abox.getBranches();
            branches.subList(lastBranch, branches.size()).clear();
            Branch newBranch = (Branch) branches.get(lastBranch - 1);

            if( log.isDebugEnabled() ) 
                log.debug("Backtracking to branch " + lastBranch + " -> " + newBranch);
            if(lastBranch != newBranch.branch)
                throw new InternalReasonerException("Backtrack: Trying to backtrack to branch "
                    + lastBranch + " but got " + newBranch.branch);

            if(newBranch.tryNext < newBranch.tryCount)
                newBranch.setLastClash( abox.getClash().depends );

            newBranch.tryNext++;

            if(newBranch.tryNext < newBranch.tryCount) {
                restore(newBranch);

                branchFound = newBranch.tryNext();
            }
            else
                abox.getClash().depends.remove(lastBranch);
            if(!branchFound) {
                if( log.isDebugEnabled() ) 
                    log.debug("Failed at branch " + lastBranch);
            }
        }

        return branchFound;
    }

    ABox complete() {
        initialize();
        
        while(!abox.isComplete()) {

            while(abox.changed && !abox.isClosed()) {
                abox.changed = false;

                if( log.isDebugEnabled() ) {
                    log.debug("Branch: " + abox.getBranch() + ", Depth: " + abox.treeDepth
                        + ", Size: " + abox.getNodes().size());
                    printBlocked();
                    abox.printTree();
                    abox.validate();
                }
                //Here optimization on separating indiciduals in KB

                IndividualIterator i = abox.getIndIterator();
                if(PelletOptions.USE_OPTIMIZEDINDIVIDUALS == true) {
                    if(((EconnectedKB) abox.getKB()).getCheckAll() == false) {
                        String ont2 = abox.getKB().getOntology();
                        IndividualIterator it = new FilteredIterator(ont2);
                        i = it;
                    }
                }
                timers.startTimer("applyUnfoldingRule");
                applyUnfoldingRule(i);
                timers.stopTimer("applyUnfoldingRule");
                if(abox.isClosed()) break;

                timers.startTimer("applyDisjunctionRule");
                applyDisjunctionRule(i);
                timers.stopTimer("applyDisjunctionRule");
                if(abox.isClosed()) break;

                timers.startTimer("applySomeValuesRule");
                applySomeValuesRule(i);
                timers.stopTimer("applySomeValuesRule");
                if(abox.isClosed()) break;

                timers.startTimer("applyMinRule");
                applyMinRule(i);
                timers.stopTimer("applyMinRule");
                // min rule cannot introduce a clash

                applyNominalRule(i);
                if(abox.isClosed()) break;

                timers.startTimer("applyMaxRule");
                applyMaxRule(i);
                timers.stopTimer("applyMaxRule");
                if(abox.isClosed()) break;

//                if(hasClash()) break;
            }

            if(abox.isClosed()) {
                if( log.isDebugEnabled() ) 
                    log.debug( "Clash at Branch (" + abox.getBranch() + ") " + abox.getClash() );

                if(backtrack())
                    abox.setClash(null);
                else
                    abox.setComplete(true);
            }
            else
                abox.setComplete(true);
        }//End while

        return abox;
    }

}