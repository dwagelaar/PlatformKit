// The MIT License
//
// Copyright (c) 2003 Ron Alford, Mike Grove, Bijan Parsia, Evren Sirin
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

package org.mindswap.pellet;


import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.mindswap.pellet.exceptions.InternalReasonerException;
import org.mindswap.pellet.utils.ATermUtils;
import org.mindswap.pellet.utils.SetUtils;
import org.mindswap.pellet.utils.fsm.TransitionGraph;

import aterm.ATerm;
import aterm.ATermAppl;
import aterm.ATermList;

/*
 * Created on Aug 27, 2003
 *
 */

/**
 * @author Evren Sirin
 *
 */
public class Role {
	final public static String[] TYPES = {"Untyped", "Object", "Datatype", "Annotation", "Ontology"	};
    /**
     * @deprecated Use UNTYPED instead
     */
    final public static int UNDEFINED  = 0;
	final public static int UNTYPED    = 0;
	final public static int OBJECT     = 1;
	final public static int DATATYPE   = 2;
	final public static int ANNOTATION = 3;
	final public static int ONTOLOGY   = 4;
	final public static int LINK   = 5;
	private String foreignOntology;
	//***************************************************
	
	private ATermAppl   name;
	
	private int  type = UNTYPED; 
	private Role inverse = null;

	private Set subRoles = SetUtils.EMPTY_SET;
	private Set superRoles = SetUtils.EMPTY_SET;
    private Set disjointRoles = SetUtils.EMPTY_SET;
    private Set subRoleChains = SetUtils.EMPTY_SET;
    
	private Set functionalSupers = SetUtils.EMPTY_SET;
	private Set transitiveSubRoles = SetUtils.EMPTY_SET;
	
	private ATermAppl domain = null;
	private ATermAppl range  = null;

	private Set domains = null;
	private Set ranges  = null;
    
    private TransitionGraph tg;

    public static int TRANSITIVE     = 0x01;
    public static int FUNCTIONAL     = 0x02;
    public static int INV_FUNCTIONAL = 0x04;
    public static int REFLEXIVE      = 0x08;
    public static int IRREFLEXIVE    = 0x10;
    public static int ANTI_SYM       = 0x20;

    public static int SIMPLE         = 0x40;    
    public static int COMPLEX_SUB    = 0x80;
    
    private int flags = SIMPLE;
    
	public Role(ATermAppl name) {
		this(name, UNTYPED);
	}
   
	public Role(ATermAppl name, int type) {
		this.name = name;
		this.type = type;
		
		addSubRole(this);
		addSuperRole(this);
	}
	
	public boolean equals(Object o) {
		if(o instanceof Role)
			return name == ((Role)o).getName();		
		
		return false;
	}

	public String toString() {
		return name.getArity() == 0 ? name.getName() : name.toString();
	}
	
	public String debugString() {
		String str = "(" + TYPES[type] + "Role " + name;
		if(isTransitive()) str += " Transitive";
        if(isReflexive()) str += " Reflexive";
        if(isIrreflexive()) str += " Irreflexive";
		if(isSymmetric()) str += " Symmetric";
        if(isAntisymmetric()) str += " Antisymmetric";
		if(isFunctional()) str += " Functional";
		if(isInverseFunctional()) str += " InverseFunctional";
		if(hasComplexSubRole()) str += " Complex";
		if(type == OBJECT || type == DATATYPE) {
			if(domain != null) str += " domain=" + domain;
			if(range != null) str += " range=" + range;
			str += " superPropertyOf=" + subRoles;
			str += " subPropertyOf=" + superRoles;
            str += " hasSubPropertyChain=" + subRoleChains;
            str += " disjointWith=" + disjointRoles;
		}
		str += ")";
		
		return str; 
	}

    public void addSubRoleChain( ATermList chain ) {
        if( chain.isEmpty() )
            throw new InternalReasonerException( "Adding a subproperty chain that is empty!" );
        else if( chain.getLength() == 1 )
            throw new InternalReasonerException( "Adding a subproperty chain that has a single element!" );

        subRoleChains = SetUtils.add( chain, subRoleChains );        
        setSimple( false );
        
        boolean transitiveChain = ATermUtils.isTransitiveChain( chain, name );
        if( transitiveChain ) {
        	if( !isTransitive() ) 
        		setTransitive( true );
        }
        else
        	setHasComplexSubRole( true );        	
    }

    public void removeSubRoleChain(ATermList chain) {
        subRoleChains = SetUtils.remove( chain, subRoleChains );
        
        if( isTransitive() && ATermUtils.isTransitiveChain( chain, name ) )         
            setTransitive( false );    
    }
    
    public void removeSubRoleChains() {
        subRoleChains = SetUtils.EMPTY_SET;
        
        if( isTransitive() )         
            setTransitive( false );    
    }

	/**
	 * r is subrole of this role
     * 
	 * @param r
	 */
	public void addSubRole(Role r) {
		subRoles = SetUtils.add( r, subRoles );
	}
    
    public void removeSubRole(Role r) {
        subRoles = SetUtils.remove( r, subRoles );
    }
    
	/**
	 * r is superrole of this role
     * 
	 * @param r
	 */
	public void addSuperRole(Role r) {		
        superRoles = SetUtils.add( r, superRoles );
	}
    
    public void addDisjointRole(Role r) {        
        disjointRoles = SetUtils.add( r, disjointRoles );
    }
	
	void normalize() {
		if( domains != null ) {
		    if( domains.size() == 1 )
		        domain = (ATermAppl) domains.iterator().next();
		    else
		        domain = ATermUtils.makeSimplifiedAnd( domains );
			domains = null;
		}
		if( ranges != null ) {
		    if( ranges.size() == 1 )
		        range = (ATermAppl) ranges.iterator().next();
		    else
		        range = ATermUtils.makeSimplifiedAnd( ranges );
			ranges = null;
		}
	}
	
	public void addDomain(ATermAppl a) {
	    if( domains == null )
	        domains = new HashSet();
	    domains.add( ATermUtils.normalize( a ) );
	}
	
	public void addRange(ATermAppl a) {
	    if( ranges == null )
	        ranges = new HashSet();
	    ranges.add( ATermUtils.normalize( a ) );
	}

	public void addDomains(Set a) {
	    if( domains == null )
	        domains = new HashSet();
	    domains.addAll( a );
	}
	
	public void addRanges(Set a) {
	    if( ranges == null )
	        ranges = new HashSet();
	    ranges.addAll( a );
	}
	
	public boolean isObjectRole() {
		return type == OBJECT; 
	}	

	//Added for E-connections
	public boolean isLinkRole() {
		return type == LINK; 
	}	

	public boolean isDatatypeRole() {
		return type == DATATYPE; 
	}

	public boolean isOntologyRole() {
		return type == Role.ONTOLOGY; 
	}	
	/**
	 * check if a role is declared as datatype property
	 */
	public boolean isAnnotationRole() {
		return type == Role.ANNOTATION; 
	}
    
    public boolean isUntypedRole() {
        return type == UNTYPED;
    }

	/**
	 * @return
	 */
	public Role getInverse() {
		return inverse;
	}

	public boolean hasNamedInverse() {
		return inverse != null && !inverse.isAnon();
	}
	
	public boolean hasComplexSubRole() {
		return (flags & COMPLEX_SUB) != 0;
	}

	public boolean isFunctional() {
		return (flags & FUNCTIONAL) != 0;
	}	

	public boolean isInverseFunctional() {
		return (flags & INV_FUNCTIONAL) != 0; 
	}

	public boolean isSymmetric() {
		return inverse != null && inverse.equals(this); 
	}
    
    public boolean isAntisymmetric() {
        return (flags & ANTI_SYM) != 0; 
    }    

	public boolean isTransitive() {
		return (flags & TRANSITIVE) != 0;
	}
    
    public boolean isReflexive() {
        return (flags & REFLEXIVE) != 0;
    }   
	
    public boolean isIrreflexive() {
        return (flags & IRREFLEXIVE) != 0;
    }   
    
	public boolean isAnon() {
	    return name.getArity() != 0;
	}
	
	public ATermAppl getName() {
		return name;
	}

	public ATermAppl getDomain() {
		return domain;
	}

	public ATermAppl getRange() {
		return range;
	}

	public Set getDomains() {
		return domains;
	}

	public Set getRanges() {
		return ranges;
	}

	public Set getSubRoles() {
		return subRoles;
	}
    
    public Set getSubRoleChains() {
        return subRoleChains;
    }    

	/**
	 * @return
	 */
	public Set getSuperRoles() {
		return superRoles;
	}
    
    public Set getDisjointRoles() {
        return disjointRoles;
    }

	/**
	 * @return
	 */
	public int getType() {
		return type;
	}

	public String getTypeName() {
		return TYPES[type];
	}
	
	public boolean isSubRoleOf(Role r) {
		return superRoles.contains(r);
	}

	public boolean isSuperRoleOf(Role r) {
		return subRoles.contains(r);
	}

	public void setInverse(Role term) {
		inverse = term;
	}

	public void setFunctional( boolean b ) {
        if( b )
            flags |= FUNCTIONAL;
        else
            flags &= ~FUNCTIONAL;            
	}

    public void setInverseFunctional(boolean b) {
        if( b )
            flags |= INV_FUNCTIONAL;
        else
            flags &= ~INV_FUNCTIONAL;  
    }
    
	public void setTransitive(boolean b) {
        ATermList roleChain = ATermUtils.makeList( new ATerm[] { name, name } );
        if( b ) {
            flags |= TRANSITIVE;
            addSubRoleChain( roleChain );
        }
        else {
            flags &= ~TRANSITIVE;
            removeSubRoleChain( roleChain );
        }
	}
    
    public void setReflexive(boolean b) {
        if( b )
            flags |= REFLEXIVE;
        else
            flags &= ~REFLEXIVE;  
    }        
	
    public void setIrreflexive(boolean b) {
        if( b )
            flags |= IRREFLEXIVE;
        else
            flags &= ~IRREFLEXIVE;  
    }        
    
    public void setAntisymmetric(boolean b) {
        if( b )
            flags |= ANTI_SYM;
        else
            flags &= ~ANTI_SYM;  
    }        
    
    public void setHasComplexSubRole(boolean b) {
        if( b )
            flags |= COMPLEX_SUB;
        else
            flags &= ~COMPLEX_SUB;  
    } 

	public void setType(int type) {
		this.type = type;
	}
    
    public void setSubRoleChains(Set subRoleChains) {
        this.subRoleChains = subRoleChains;
    }
	
	/**
	 * @param subRoles The subRoles to set.
	 */
	public void setSubRoles(Set subRoles) {
		this.subRoles = subRoles;
	}
	
	/**
	 * @param superRoles The superRoles to set.
	 */
	public void setSuperRoles(Set superRoles) {
		this.superRoles = superRoles;
	}

	/**
	 * @return Returns the functionalSuper.
	 */
	public Set getFunctionalSupers() {
		return functionalSupers;
	}
	
	/**
	 * @param functionalSuper The functionalSuper to set.
	 */
	public void addFunctionalSuper(Role r) {
        for(Iterator i = functionalSupers.iterator(); i.hasNext();) {
            Role fs = (Role) i.next();
            if( fs.isSubRoleOf( r ) ) {
                functionalSupers = SetUtils.remove( fs, functionalSupers );                
                break;
            }
            else if( r.isSubRoleOf( fs ) ) {
                return;
            }
        }
        functionalSupers = SetUtils.add( r, functionalSupers );    
	}

    public boolean isSimple() {
        return (flags & SIMPLE) != 0;
    }
    
    void setSimple( boolean b ) {
        if( b )
            flags |= SIMPLE;
        else
            flags &= ~SIMPLE;  
    }

//	public boolean isSimple() {
//	    return !isTransitive() && transitiveSubRoles.isEmpty();
//	}
	
	/**
	 * @return Returns transitive sub roles.
	 */
	public Set getTransitiveSubRoles() {
		return transitiveSubRoles;
	}
	
	/**
	 * @param functionalSuper The functionalSuper to set.
	 */
	public void addTransitiveSubRole( Role r ) {
		setSimple( false );
		
	    if( transitiveSubRoles.isEmpty() ) {
	        transitiveSubRoles = SetUtils.singleton( r );
	    }
	    else if( transitiveSubRoles.size() == 1 ) {
            Role tsr = (Role) transitiveSubRoles.iterator().next();
	        if( tsr.isSubRoleOf( r ) ) {
	            transitiveSubRoles = SetUtils.singleton( r );
	        }
	        else if( !r.isSubRoleOf( tsr ) ) {
	            transitiveSubRoles = new HashSet( 2 );
	            transitiveSubRoles.add( tsr );
	            transitiveSubRoles.add( r );
	        }	            
        }
        else {
	        for(Iterator i = transitiveSubRoles.iterator(); i.hasNext();) {
                Role tsr = (Role) i.next();
		        if( tsr.isSubRoleOf( r ) ) {
		            transitiveSubRoles.remove( tsr );
		            transitiveSubRoles.add( r );
		            return;
		        }
		        else if( r.isSubRoleOf( tsr ) ) {
		            return;
		        }
            }
	        transitiveSubRoles.add( r );
        }	    
	}

	/**
	 * @return Returns the foreignOntology.
	 */
	public String getForeignOntology() {
		return foreignOntology;
	}
	
	/**
	 * @param foreignOntology The foreignOntology to set.
	 */
	public void setForeignOntology(String foreignOntology) {
		this.foreignOntology = foreignOntology;
	}

    protected Role copy(Map conversion) {
        Role newr;
        if(conversion.containsKey(this)) {
            newr = (Role)conversion.get(this);
        } else {
            newr = new Role(name);
            conversion.put(this, newr);
        }
        // first, we need to copy all the easy stuff: foreignOnt,
        // name, type, domains, ranges, and the assorted booleans
        newr.foreignOntology = foreignOntology;
        // newr.name should be set already
        newr.type = type;
        if(domains != null) {
            newr.domains = (Set)((HashSet)domains).clone();
        } else {
            newr.domains = null;
        }
        if(ranges != null) {
            newr.ranges = (Set)((HashSet)ranges).clone();
        } else {
            newr.ranges = null;
        }
        newr.domain = domain;
        newr.range = range;

	    newr.flags = flags;

        // fix the inverse
        if(inverse != null) {
            if(!conversion.containsKey(inverse)) {
                conversion.put(inverse, new Role(inverse.name));
            }
            newr.inverse = (Role)conversion.get(inverse);
        } else {
            newr.inverse = null;
        }
        // fix the subRoles, superRoles, functionalSupers, and
        // transitiveSubRoles
        newr.subRoles = roleSetCopy(subRoles, conversion);
        newr.superRoles = roleSetCopy(superRoles, conversion);
        newr.disjointRoles = roleSetCopy(disjointRoles, conversion);
        newr.functionalSupers = roleSetCopy(functionalSupers, conversion);
//        newr.transitiveSubRoles = roleSetCopy(transitiveSubRoles, conversion);
        return newr;
    }
    private Set roleSetCopy(Set roleset, Map conversion) {
        if(roleset == null) {
            return null;
        }
        Set newroles = new HashSet();
        Iterator j = roleset.iterator();
        while(j.hasNext()) {
            Role role = (Role)j.next();
            if(!conversion.containsKey(role)) {
                conversion.put(role, new Role(role.name));
            }
            newroles.add(conversion.get(role));
        }
        return newroles;
    }

    public void setFSM( TransitionGraph tg ) {
        this.tg = tg;        
    }

    public TransitionGraph getFSM() {
        return tg;        
    }

}
