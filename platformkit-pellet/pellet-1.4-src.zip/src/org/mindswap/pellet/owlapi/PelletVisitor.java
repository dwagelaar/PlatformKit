// The MIT License
//
// Copyright (c) 2003 Ron Alford, Mike Grove, Bijan Parsia, Evren Sirin
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

package org.mindswap.pellet.owlapi;

import java.net.URI;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mindswap.pellet.KnowledgeBase;
import org.mindswap.pellet.PelletOptions;
import org.mindswap.pellet.datatypes.Datatype;
import org.mindswap.pellet.datatypes.DatatypeReasoner;
import org.mindswap.pellet.datatypes.UnknownDatatype;
import org.mindswap.pellet.datatypes.XSDAtomicType;
import org.mindswap.pellet.rete.Constant;
import org.mindswap.pellet.rete.Rule;
import org.mindswap.pellet.rete.Term;
import org.mindswap.pellet.rete.Triple;
import org.mindswap.pellet.rete.Variable;
import org.mindswap.pellet.utils.ATermUtils;
import org.mindswap.pellet.utils.QNameProvider;
import org.semanticweb.owl.model.*;
import org.semanticweb.owl.vocab.*;

import aterm.ATerm;
import aterm.ATermAppl;
import aterm.ATermList;

/**
 * PelletVisitor
 *  
 */

public class PelletVisitor implements OWLObjectVisitor {
	private static final long	serialVersionUID	= 8211773146996997500L;

	protected static Log		log					= LogFactory.getLog( PelletLoader.class );

	public static QNameProvider	qnames				= new QNameProvider();

	KnowledgeBase				kb;

	ATermAppl					term;
	
	Term						swrlTerm;
	
	Triple						swrlTriple;

	public PelletVisitor(KnowledgeBase kb) {
		this.kb = kb;
	}

	public ATermAppl result() {
		return term;
	}

	public void reset() {
		term = null;
	}

	public ATermAppl term(URI u) {
		if( PelletOptions.USE_LOCAL_NAME )
			return ATermUtils.makeTermAppl( u.getFragment() );
		else if( PelletOptions.USE_QNAME )
			return ATermUtils.makeTermAppl( qnames.shortForm( u ) );

		return ATermUtils.makeTermAppl( u.toString() );
	}

	public void visit(OWLClass c) throws OWLException {
		URI uri = c.getURI();
		
		if( uri.equals( OWLRDFVocabulary.OWL_THING.getURI() ) )
			term = ATermUtils.TOP;
		else if( uri.equals( OWLRDFVocabulary.OWL_NOTHING.getURI() ) )
			term = ATermUtils.BOTTOM;
		else
			term = term( uri );
	}

	public void visit(OWLIndividual ind) throws OWLException {
		term = term( ind.getURI() );
	}

	public void visit(OWLObjectProperty prop) throws OWLException {
		term = term( prop.getURI() );
	}
	
	public void visit(OWLObjectPropertyInverse propInv) throws OWLException {
		propInv.getInverse().accept( this );
		ATermAppl p = term;
		
		term = ATermUtils.makeInv( p );		
	}

	public void visit(OWLDataProperty prop) throws OWLException {
		term = term( prop.getURI() );
	}

	public void visit(OWLTypedConstant constant) throws OWLException {
		String lexicalValue = constant.getLiteral();		
		constant.getDataType().accept( this );
		ATerm datatype = term;

		term = ATermUtils.makeTypedLiteral( lexicalValue, datatype.toString() );
	}

	public void visit(OWLUntypedConstant constant) throws OWLException {
		String lexicalValue = constant.getLiteral();
		String lang = constant.getLang();

		if( lang != null )
			term = ATermUtils.makePlainLiteral( lexicalValue, lang );
		else
			term = ATermUtils.makePlainLiteral( lexicalValue );
	}

	public void visit(OWLDataType ocdt) throws OWLException {
		term = term( ocdt.getURI() );

		if( PelletOptions.AUTO_XML_SCHEMA_LOADING )
			kb.loadDatatype( term );
		else
			kb.addDatatype( term );
	}

	public void visit(OWLObjectIntersectionOf and) throws OWLException {
		ATermList ops = ATermUtils.EMPTY_LIST;
		for( Iterator it = and.getOperands().iterator(); it.hasNext(); ) {
			OWLDescription desc = (OWLDescription) it.next();
			desc.accept( this );
			ops = ops.insert( result() );
		}
		term = ATermUtils.makeAnd( ops );
	}

	public void visit(OWLObjectUnionOf or) throws OWLException {
		ATermList ops = ATermUtils.EMPTY_LIST;
		for( Iterator it = or.getOperands().iterator(); it.hasNext(); ) {
			OWLDescription desc = (OWLDescription) it.next();
			desc.accept( this );
			ops = ops.insert( result() );
		}
		term = ATermUtils.makeOr( ops );
	}

	public void visit(OWLObjectComplementOf not) throws OWLException {
		OWLDescription desc = not.getOperand();
		desc.accept( this );

		term = ATermUtils.makeNot( term );
	}

	public void visit(OWLObjectOneOf enumeration) throws OWLException {
		ATermList ops = ATermUtils.EMPTY_LIST;
		for( Iterator it = enumeration.getIndividuals().iterator(); it.hasNext(); ) {
			OWLIndividual desc = (OWLIndividual) it.next();
			desc.accept( this );
			ops = ops.insert( ATermUtils.makeValue( result() ) );
		}
		term = ATermUtils.makeOr( ops );
	}

	public void visit(OWLObjectSomeRestriction restriction) throws OWLException {
		restriction.getProperty().accept( this );
		ATerm p = term;
		restriction.getFiller().accept( this );
		ATerm c = term;

		term = ATermUtils.makeSomeValues( p, c );
	}

	public void visit(OWLObjectAllRestriction restriction) throws OWLException {
		restriction.getProperty().accept( this );
		ATerm p = term;
		restriction.getFiller().accept( this );
		ATerm c = term;

		term = ATermUtils.makeAllValues( p, c );
	}

	public void visit(OWLObjectValueRestriction restriction) throws OWLException {
		restriction.getProperty().accept( this );
		ATerm p = term;
		restriction.getValue().accept( this );
		ATermAppl ind = term;

		term = ATermUtils.makeHasValue( p, ind );
	}

	public void visit(OWLObjectExactCardinalityRestriction restriction) throws OWLException {
		restriction.getProperty().accept( this );
		ATerm p = term;
		int n = restriction.getCardinality();
		restriction.getFiller().accept( this );
		ATermAppl desc = term;

		term = ATermUtils.makeCard( p, n, desc );
	}

	public void visit(OWLObjectMaxCardinalityRestriction restriction) throws OWLException {
		restriction.getProperty().accept( this );
		ATerm p = term;
		int n = restriction.getCardinality();
		restriction.getFiller().accept( this );
		ATermAppl desc = term;

		term = ATermUtils.makeMax( p, n, desc );

	}

	public void visit(OWLObjectMinCardinalityRestriction restriction) throws OWLException {
		restriction.getProperty().accept( this );
		ATerm p = term;
		int n = restriction.getCardinality();
		restriction.getFiller().accept( this );
		ATermAppl desc = term;

		term = ATermUtils.makeMin( p, n, desc );
	}

	public void visit(OWLDataExactCardinalityRestriction restriction) throws OWLException {
		restriction.getProperty().accept( this );
		ATerm p = term;
		int n = restriction.getCardinality();
		restriction.getFiller().accept( this );
		ATermAppl desc = term;

		term = ATermUtils.makeCard( p, n, desc );
	}

	public void visit(OWLDataMaxCardinalityRestriction restriction) throws OWLException {
		restriction.getProperty().accept( this );
		ATerm p = term;
		int n = restriction.getCardinality();
		restriction.getFiller().accept( this );
		ATermAppl desc = term;

		term = ATermUtils.makeMax( p, n, desc );
	}

	public void visit(OWLDataMinCardinalityRestriction restriction) throws OWLException {
		restriction.getProperty().accept( this );
		ATerm p = term;
		int n = restriction.getCardinality();
		restriction.getFiller().accept( this );
		ATermAppl desc = term;

		term = ATermUtils.makeMin( p, n, desc );
	}

	public void visit(OWLEquivalentClassesAxiom axiom) throws OWLException {
		Iterator eqs = axiom.getDescriptions().iterator();
		if( eqs.hasNext() ) {
			OWLDescription desc1 = (OWLDescription) eqs.next();
			desc1.accept( this );
			ATermAppl c1 = term;

			while( eqs.hasNext() ) {
				OWLDescription desc2 = (OWLDescription) eqs.next();
				desc2.accept( this );
				ATermAppl c2 = term;

				kb.addEquivalentClass( c1, c2 );
			}
		}
	}

	public void visit(OWLDisjointClassesAxiom axiom) throws OWLException {
		List classes = new ArrayList();
		for( Iterator i = axiom.getDescriptions().iterator(); i.hasNext(); ) {
			OWLDescription desc = (OWLDescription) i.next();
			desc.accept( this );
			ATermAppl c = term;
			classes.add( c );
		}

		kb.addDisjointClasses( classes );
	}

	public void visit(OWLSubClassAxiom axiom) throws OWLException {
		axiom.getSubClass().accept( this );
		ATermAppl c1 = term;
		axiom.getSuperClass().accept( this );
		ATermAppl c2 = term;

		kb.addSubClass( c1, c2 );
	}

	public void visit(OWLEquivalentObjectPropertiesAxiom axiom) throws OWLException {
		Object[] eqs = axiom.getProperties().toArray();
		for( int i = 0; i < eqs.length; i++ ) {
			for( int j = i + 1; j < eqs.length; j++ ) {
				OWLProperty prop1 = (OWLProperty) eqs[i];
				OWLProperty prop2 = (OWLProperty) eqs[j];
				prop1.accept( this );
				ATermAppl p1 = term;
				prop2.accept( this );
				ATermAppl p2 = term;

				kb.addEquivalentProperty( p1, p2 );
			}
		}
	}
	
	public void visit(OWLEquivalentDataPropertiesAxiom axiom) throws OWLException {
		Object[] eqs = axiom.getProperties().toArray();
		for( int i = 0; i < eqs.length; i++ ) {
			for( int j = i + 1; j < eqs.length; j++ ) {
				OWLProperty prop1 = (OWLProperty) eqs[i];
				OWLProperty prop2 = (OWLProperty) eqs[j];
				prop1.accept( this );
				ATermAppl p1 = term;
				prop2.accept( this );
				ATermAppl p2 = term;

				kb.addEquivalentProperty( p1, p2 );
			}
		}
	}

	public void visit(OWLDifferentIndividualsAxiom axiom) throws OWLException {
		Object[] inds = axiom.getIndividuals().toArray();
		for( int i = 0; i < inds.length; i++ ) {
			((OWLIndividual) inds[i]).accept( this );
			ATermAppl i1 = term;
			for( int j = i + 1; j < inds.length; j++ ) {
				((OWLIndividual) inds[j]).accept( this );
				ATermAppl i2 = term;

				kb.addDifferent( i1, i2 );
			}
		}
	}

	public void visit(OWLSameIndividualsAxiom axiom) throws OWLException {
		Iterator eqs = axiom.getIndividuals().iterator();
		if( eqs.hasNext() ) {
			((OWLIndividual) eqs.next()).accept( this );
			ATermAppl i1 = term;

			while( eqs.hasNext() ) {
				((OWLIndividual) eqs.next()).accept( this );
				ATermAppl i2 = term;

				kb.addSame( i1, i2 );
			}
		}
	}

	public void visit(OWLDataOneOf enumeration) throws OWLException {
		ATermList ops = ATermUtils.EMPTY_LIST;
		for( Iterator it = enumeration.getValues().iterator(); it.hasNext(); ) {
			OWLConstant value = (OWLConstant) it.next();
			value.accept( this );
			ops = ops.insert( ATermUtils.makeValue( result() ) );
		}
		term = ATermUtils.makeOr( ops );
	}

	public void visit(OWLDataAllRestriction restriction) throws OWLException {
		restriction.getProperty().accept( this );
		ATerm p = term;
		restriction.getFiller().accept( this );
		ATerm c = term;

		term = ATermUtils.makeAllValues( p, c );
	}

	public void visit(OWLDataSomeRestriction restriction) throws OWLException {
		restriction.getProperty().accept( this );
		ATerm p = term;
		restriction.getFiller().accept( this );
		ATerm c = term;

		term = ATermUtils.makeSomeValues( p, c );
	}

	public void visit(OWLDataValueRestriction restriction) throws OWLException {
		restriction.getProperty().accept( this );
		ATermAppl p = term;
		restriction.getValue().accept( this );
		ATermAppl dv = term;

		term = ATermUtils.makeHasValue( p, dv );
	}

	public void visit(OWLOntology ont) throws OWLException {
		defineEntities( ont );

		Set axioms = ont.getAxioms();
		for( Iterator i = axioms.iterator(); i.hasNext(); ) {
			OWLAxiom axiom = (OWLAxiom) i.next();
			axiom.accept( this );
		}
		
		Set rules = ont.getRules();
		for( Iterator i = rules.iterator(); i.hasNext(); ) {
			OWLAxiom axiom = (OWLAxiom) i.next();
			axiom.accept( this );
		}
	}	
	
	public ATermAppl term(OWLObject d) throws OWLException {
		reset();
		d.accept( this );

		ATermAppl a = term;

		if( a == null )
			throw new OWLException( "Cannot create ATerm from description " + d );

		return a;
	}

	private void defineEntities(OWLOntology ontology) throws OWLException {
		Iterator it = null;

		it = ontology.getReferencedClasses().iterator();
		while( it.hasNext() )
			kb.addClass( term( (OWLClass) it.next() ) );

		it = ontology.getReferencedObjectProperties().iterator();
		while( it.hasNext() ) 
			kb.addObjectProperty( term( (OWLObjectProperty) it.next() ) );		

		it = ontology.getReferencedDataProperties().iterator();
		while( it.hasNext() )
			kb.addDatatypeProperty( term( (OWLDataProperty) it.next() ) );

		it = ontology.getReferencedIndividuals().iterator();
		while( it.hasNext() )
			kb.addIndividual( term( (OWLIndividual) it.next() ) );
	}
	
	public void visit(OWLObjectSelfRestriction restriction) throws OWLException {
		restriction.getProperty().accept( this );
		ATermAppl p = term;

		term = ATermUtils.makeSelf( p );
	}

	public void visit(OWLDisjointObjectPropertiesAxiom axiom) throws OWLException {
		Object[] disjs = axiom.getProperties().toArray();
		for( int i = 0; i < disjs.length; i++ ) {
			for( int j = i + 1; j < disjs.length; j++ ) {
				OWLProperty prop1 = (OWLProperty) disjs[i];
				OWLProperty prop2 = (OWLProperty) disjs[j];
				prop1.accept( this );
				ATermAppl p1 = term;
				prop2.accept( this );
				ATermAppl p2 = term;

				kb.addDisjointProperty( p1, p2 );
			}
		}
	}

	public void visit(OWLDisjointDataPropertiesAxiom axiom) throws OWLException {
		Object[] disjs = axiom.getProperties().toArray();
		for( int i = 0; i < disjs.length; i++ ) {
			for( int j = i + 1; j < disjs.length; j++ ) {
				OWLDescription desc1 = (OWLDescription) disjs[i];
				OWLDescription desc2 = (OWLDescription) disjs[j];
				desc1.accept( this );
				ATermAppl p1 = term;
				desc2.accept( this );
				ATermAppl p2 = term;

				kb.addDisjointProperty( p1, p2 );
			}
		}
	}

	public void visit(OWLObjectPropertyChainSubPropertyAxiom axiom) throws OWLException {
		axiom.getSuperProperty().accept( this );
		ATerm prop = result();

		List propChain = axiom.getPropertyChain();
		ATermList chain = ATermUtils.EMPTY_LIST;
		for( int i = propChain.size() - 1; i >= 0; i-- ) {
			OWLObjectProperty p = (OWLObjectProperty) propChain.get( i );

			p.accept( this );
			chain = chain.insert( result() );
		}

		kb.addSubProperty( chain, prop );
	}

	public void visit(OWLDisjointUnionAxiom axiom) throws OWLException {
		axiom.getOWLClass().accept( this );
		ATermAppl c = term;

		ATermList classes = ATermUtils.EMPTY_LIST;
		for( Iterator it = axiom.getDescriptions().iterator(); it.hasNext(); ) {
			OWLDescription desc = (OWLDescription) it.next();
			desc.accept( this );
			classes = classes.insert( result() );
		}

		kb.addDisjointClasses( classes );
		kb.addEquivalentClass( c, ATermUtils.makeOr( classes ) );
	}

	public void visit(OWLDataComplementOf node) throws OWLException {
		String name = "Datatype" + node.hashCode();

		DatatypeReasoner dtReasoner = kb.getDatatypeReasoner();
		Datatype datatype = UnknownDatatype.instance;

		node.getDataRange().accept( this );
		Datatype baseDatatype = dtReasoner.getDatatype( term );

		datatype = dtReasoner.negate( baseDatatype );

		kb.addDatatype( name, datatype );
		term = ATermUtils.makeTermAppl( name );
	}

	public void visit(OWLDataRangeRestriction node) throws OWLException {
		String name = "Datatype" + node.hashCode();

		DatatypeReasoner dtReasoner = kb.getDatatypeReasoner();
		Datatype datatype = UnknownDatatype.instance;

		node.getDataRange().accept( this );
		Datatype baseDatatype = dtReasoner.getDatatype( term );

		if( baseDatatype instanceof XSDAtomicType ) {
			XSDAtomicType xsdType = (XSDAtomicType) baseDatatype;

			Set facets = node.getFacetRestrictions();
			for( Iterator i = facets.iterator(); i.hasNext(); ) {
				OWLDataRangeFacetRestriction restr = (OWLDataRangeFacetRestriction) i.next();
				OWLRestrictedDataRangeFacetVocabulary facet = restr.getFacet();
				OWLConstant facetValue = restr.getFacetValue();

				if( facet.equals( OWLRestrictedDataRangeFacetVocabulary.MIN_INCLUSIVE ) ) {
					Object value = xsdType.getPrimitiveType().getValue(
							facetValue.getLiteral(), xsdType.getURI() );
					xsdType = xsdType.restrictMinInclusive( value );
				}
				else if( facet.equals( OWLRestrictedDataRangeFacetVocabulary.MAX_INCLUSIVE ) ) {
					Object value = xsdType.getPrimitiveType().getValue(
							facetValue.getLiteral(), xsdType.getURI() );
					xsdType = xsdType.restrictMaxInclusive( value );
				}
				else if( facet.equals( OWLRestrictedDataRangeFacetVocabulary.MIN_EXCLUSIVE ) ) {
					Object value = xsdType.getPrimitiveType().getValue(
							facetValue.getLiteral(), xsdType.getURI() );
					xsdType = xsdType.restrictMinExclusive( value );
				}
				else if( facet.equals( OWLRestrictedDataRangeFacetVocabulary.MAX_EXCLUSIVE ) ) {
					Object value = xsdType.getPrimitiveType().getValue(
							facetValue.getLiteral(), xsdType.getURI() );
					xsdType = xsdType.restrictMaxExclusive( value );
				}
				else if( facet.equals( OWLRestrictedDataRangeFacetVocabulary.TOTAL_DIGITS ) ) {
					int n = Integer.parseInt( facetValue.getLiteral() );
					xsdType = xsdType.restrictTotalDigits( n );
				}
				else if( facet.equals( OWLRestrictedDataRangeFacetVocabulary.FRACTION_DIGITS ) ) {
					int n = Integer.parseInt( facetValue.getLiteral() );
					xsdType = xsdType.restrictFractionDigits( n );
				}
				else if( facet.equals( OWLRestrictedDataRangeFacetVocabulary.PATTERN ) ) {
					String str = facetValue.getLiteral();
					xsdType = xsdType.restrictPattern( str );
				}
				else {
					log.warn( "Unrecognized facet " + facet );
				}
			}

			datatype = xsdType;
		}
		else
			log.warn( "Unrecognized base datatype " + node.getDataRange() );

		kb.addDatatype( name, datatype );
		term = ATermUtils.makeTermAppl( name );
	}

	public void visit(OWLAntiSymmetricObjectPropertyAxiom axiom) throws OWLException {
		axiom.getProperty().accept( this );
		ATermAppl p = term;

		kb.addAntisymmetricProperty( p );
	}

	public void visit(OWLReflexiveObjectPropertyAxiom axiom) throws OWLException {
		axiom.getProperty().accept( this );
		ATermAppl p = term;

		kb.addReflexiveProperty( p );
	}

	public void visit(OWLFunctionalObjectPropertyAxiom axiom) throws OWLException {
		axiom.getProperty().accept( this );
		ATermAppl p = term;

		kb.addFunctionalProperty( p );
	}

	public void visit(OWLNegativeObjectPropertyAssertionAxiom axiom) throws OWLException {
		axiom.getSubject().accept( this );
		ATermAppl s = term;
		axiom.getProperty().accept( this );
		ATermAppl p = term;
		axiom.getObject().accept( this );
		ATermAppl o = term;
		
		kb.addNegatedPropertyValue( p, s, o );
	}

	public void visit(OWLDataPropertyDomainAxiom axiom) throws OWLException {
		axiom.getProperty().accept( this );
		ATermAppl p = term;
		axiom.getDomain().accept( this );
		ATermAppl c = term;

		kb.addDomain( p, c );
	}

	public void visit(OWLImportsDeclaration axiom) throws OWLException {
		if( log.isDebugEnabled() )
			log.debug( "Ignoring imports declaration: " + axiom );
	}

	public void visit(OWLAxiomAnnotationAxiom axiom) throws OWLException {
		if( log.isDebugEnabled() )
			log.debug( "Ignoring axiom annotation: " + axiom );
	}

	public void visit(OWLObjectPropertyDomainAxiom axiom) throws OWLException {
		axiom.getProperty().accept( this );
		ATermAppl p = term;
		axiom.getDomain().accept( this );
		ATermAppl c = term;

		kb.addDomain( p, c );
	}

	public void visit(OWLNegativeDataPropertyAssertionAxiom axiom) throws OWLException {
		axiom.getSubject().accept( this );
		ATermAppl s = term;
		axiom.getProperty().accept( this );
		ATermAppl p = term;
		axiom.getObject().accept( this );
		ATermAppl o = term;
		
		kb.addNegatedPropertyValue( p, s, o );
	}

	public void visit(OWLObjectPropertyRangeAxiom axiom) throws OWLException {
		axiom.getProperty().accept( this );
		ATermAppl p = term;
		axiom.getRange().accept( this );
		ATermAppl c = term;

		kb.addRange( p, c );
	}

	public void visit(OWLObjectPropertyAssertionAxiom axiom) throws OWLException {
		axiom.getSubject().accept( this );
		ATermAppl subj = term;
		axiom.getProperty().accept( this );
		ATermAppl pred = term;
		axiom.getObject().accept( this );
		ATermAppl obj = term;

		kb.addPropertyValue( pred, subj, obj );
	}

	public void visit(OWLObjectSubPropertyAxiom axiom) throws OWLException {
		axiom.getSubProperty().accept( this );
		ATermAppl sub = term;
		axiom.getSuperProperty().accept( this );
		ATermAppl sup = term;

		kb.addSubProperty( sub, sup );
	}

	public void visit(OWLDeclarationAxiom axiom) throws OWLException {
		if( log.isDebugEnabled() )
			log.debug( "Ignoring declaration: " + axiom );
	}

	public void visit(OWLEntityAnnotationAxiom axiom) throws OWLException {
		if( log.isDebugEnabled() )
			log.debug( "Ignoring entity annotation: " + axiom );
	}

	public void visit(OWLOntologyAnnotationAxiom axiom) throws OWLException {
		if( log.isDebugEnabled() )
			log.debug( "Ignoring ontology annotation: " + axiom );
	}

	public void visit(OWLSymmetricObjectPropertyAxiom axiom) throws OWLException {
		axiom.getProperty().accept( this );
		ATermAppl p = term;

		kb.addSymmetricProperty( p );
	}

	public void visit(OWLDataPropertyRangeAxiom axiom) throws OWLException {
		axiom.getProperty().accept( this );
		ATermAppl p = term;
		axiom.getRange().accept( this );
		ATermAppl c = term;

		kb.addRange( p, c );
	}

	public void visit(OWLFunctionalDataPropertyAxiom axiom) throws OWLException {
		axiom.getProperty().accept( this );
		ATermAppl p = term;

		kb.addFunctionalProperty( p );
	}

	public void visit(OWLClassAssertionAxiom axiom) throws OWLException {
		axiom.getIndividual().accept( this );
		ATermAppl ind = term;
		axiom.getDescription().accept( this );
		ATermAppl c = term;
		
		kb.addType( ind, c );
	}

	public void visit(OWLDataPropertyAssertionAxiom axiom) throws OWLException {
		axiom.getSubject().accept( this );
		ATermAppl subj = term;
		axiom.getProperty().accept( this );
		ATermAppl pred = term;
		axiom.getObject().accept( this );
		ATermAppl obj = term;

		kb.addPropertyValue( pred, subj, obj );
	}

	public void visit(OWLTransitiveObjectPropertyAxiom axiom) throws OWLException {
		axiom.getProperty().accept( this );
		ATermAppl p = term;

		kb.addTransitiveProperty( p );
	}

	public void visit(OWLIrreflexiveObjectPropertyAxiom axiom) throws OWLException {
		axiom.getProperty().accept( this );
		ATermAppl p = term;

		kb.addIrreflexiveProperty( p );
	}

	public void visit(OWLDataSubPropertyAxiom axiom) throws OWLException {
		axiom.getSubProperty().accept( this );
		ATermAppl p1 = term;
		axiom.getSuperProperty().accept( this );
		ATermAppl p2 = term;

		kb.addSubProperty( p1, p2 );
	}

	public void visit(OWLInverseFunctionalObjectPropertyAxiom axiom) throws OWLException {
		axiom.getProperty().accept( this );
		ATermAppl p = term;

		kb.addInverseFunctionalProperty( p );
	}

	public void visit(OWLInverseObjectPropertiesAxiom axiom) throws OWLException {
		axiom.getFirstProperty().accept( this );
		ATermAppl p1 = term;
		axiom.getSecondProperty().accept( this );
		ATermAppl p2 = term;

		kb.addInverseProperty( p1, p2 );		
	}


	public void visit(OWLDataRangeFacetRestriction node) throws OWLException {
		// TODO Auto-generated method stub
		
	}


	public void visit(OWLObjectAnnotation annotation) throws OWLException {
		if( log.isDebugEnabled() )
			log.debug( "Ignoring object annotation: " + annotation );
	}

	public void visit(OWLConstantAnnotation annotation) throws OWLException {
		if( log.isDebugEnabled() )
			log.debug( "Ignoring constant annotation: " + annotation );
	}


	public void visit(SWRLRule rule) throws OWLException {
		Rule reteRule = new Rule();
		
		Set head = rule.getHead();
		if( head.size() > 1 ) {
			log.warn( "Ignoring SWRL rule with multiple atoms in the head: " + rule );
			return;
		}
		
		((SWRLAtom) head.iterator().next()).accept( this );
		if( swrlTriple == null ) {
			log.warn( "Ignoring SWRL rule with unsupported atoms in the head: " + rule );
			return;
		}
		reteRule.head.add( swrlTriple );
		
		Set body = rule.getBody();
		for( Iterator i = body.iterator(); i.hasNext(); ) {
			SWRLAtom atom = (SWRLAtom) i.next();
			atom.accept( this );
			
			if( swrlTriple == null ) {
				log.warn( "Ignoring SWRL rule with unsupported atoms in the body: " + rule );
				return;
			}
			reteRule.body.add( swrlTriple );
		}
		
		kb.addRule( reteRule );
	}
	
	public void visit(SWRLClassAtom atom) throws OWLException {
		OWLDescription c =  (OWLDescription) atom.getPredicate();  
		if( c.isAnonymous() ) {
			log.warn( "Ignoring SWRL class atom with anonymous class description: " + atom );
			swrlTerm = null;
			return;
		}
		
		SWRLAtomIObject v = (SWRLAtomIObject) atom.getArgument();   
		v.accept( this );
		
		Term subj = swrlTerm;				
		Term pred = Constant.TYPE;		
		Term obj = new Constant( ((OWLClass) c).getURI().toString());		
		
		swrlTriple = new Triple(subj, pred, obj);
	}

	public void visit(SWRLDataRangeAtom atom) throws OWLException {
		log.warn( "Ignoring SWRL data range atom : " + atom );
		swrlTriple = null;
	}

	public void visit(SWRLObjectPropertyAtom atom) throws OWLException {		
		if( ((OWLObjectPropertyExpression)atom.getPredicate()).isAnonymous() ) {
			swrlTriple = null;
			log.warn( "Ignoring SWRL data range atom : " + atom );
			return;
		}
		
		atom.getFirstArgument().accept( this );
		Term subj = swrlTerm;
		
		atom.getSecondArgument().accept( this );
		Term obj = swrlTerm;

		OWLObjectProperty p = (OWLObjectProperty) atom.getPredicate();
		Term pred = new Constant( p.getURI().toString() );
		
		swrlTriple = new Triple(subj, pred, obj);
	}


	public void visit(SWRLDataValuedPropertyAtom atom) throws OWLException {
		log.warn( "Ignoring SWRL data valued property atom : " + atom );
		swrlTriple = null;
	}

	public void visit(SWRLSameAsAtom atom) throws OWLException {
		log.warn( "Ignoring SWRL same as atom : " + atom );
		swrlTriple = null;
	}

	public void visit(SWRLDifferentFromAtom atom) throws OWLException {
		log.warn( "Ignoring SWRL different from atom : " + atom );
		swrlTriple = null;
	}	

	public void visit(SWRLBuiltInAtom atom) throws OWLException {
		log.warn( "Ignoring SWRL built-in atom : " + atom );
		swrlTriple = null;
	}

	public void visit(SWRLAtomDVariable dvar) throws OWLException {
		log.warn( "Ignoring SWRL data variable: " + dvar );
		swrlTerm = null;
	}

	public void visit(SWRLAtomIVariable ivar) throws OWLException {
		swrlTerm = new Variable( ivar.getURI().toString() );   
	}

	public void visit(SWRLAtomIndividualObject iobj) throws OWLException {
		swrlTerm = new Variable( iobj.getIndividual().getURI().toString() );
	}

	public void visit(SWRLAtomConstantObject cons) throws OWLException {
		log.warn( "Ignoring SWRL constant: " + cons );
		swrlTerm = null;
	}


}
