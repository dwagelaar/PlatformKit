// The MIT License
//
// Copyright (c) 2003 Ron Alford, Mike Grove, Bijan Parsia, Evren Sirin
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

/*
 * Created on Jan 10, 2004
 */
package org.mindswap.pellet.owlapi;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mindswap.pellet.KnowledgeBase;
import org.mindswap.pellet.Role;
import org.mindswap.pellet.utils.ATermUtils;
import org.semanticweb.owl.inference.OWLReasoner;
import org.semanticweb.owl.model.OWLAxiom;
import org.semanticweb.owl.model.OWLClass;
import org.semanticweb.owl.model.OWLConstant;
import org.semanticweb.owl.model.OWLDataProperty;
import org.semanticweb.owl.model.OWLDataPropertyExpression;
import org.semanticweb.owl.model.OWLDataRange;
import org.semanticweb.owl.model.OWLDataType;
import org.semanticweb.owl.model.OWLDescription;
import org.semanticweb.owl.model.OWLException;
import org.semanticweb.owl.model.OWLIndividual;
import org.semanticweb.owl.model.OWLObject;
import org.semanticweb.owl.model.OWLObjectProperty;
import org.semanticweb.owl.model.OWLObjectPropertyExpression;
import org.semanticweb.owl.model.OWLOntology;
import org.semanticweb.owl.model.OWLOntologyChange;
import org.semanticweb.owl.model.OWLOntologyChangeListener;
import org.semanticweb.owl.model.OWLOntologyManager;
import org.semanticweb.owl.model.OWLProperty;
import org.semanticweb.owl.model.OWLTypedConstant;

import aterm.ATermAppl;

/**
 * @author Evren Sirin
 */
public class Reasoner implements OWLReasoner, OWLOntologyChangeListener {
    public static Log log = LogFactory.getLog( EntailmentChecker.class );
    
    private static final long serialVersionUID = 8438190652175258123L;

	private PelletLoader loader;
	
	private OWLOntologyManager manager;	
	
	protected KnowledgeBase kb;
	
	boolean autoClassify = false;
	boolean autoRealize = false;
	
	public Reasoner() {
	    kb = new KnowledgeBase();
		loader = new PelletLoader(kb);
	}

	public boolean loadImports() {
		return loader.loadImports();
	}
	
	public OWLOntologyManager getManager() {
		return manager;
	}

	public void setManager(OWLOntologyManager manager) {
		this.manager = manager;
	}

	/**
	 * @param useImports The useImports to set.
	 */
	public void setLoadImports(boolean loadImports, boolean refreshOnt) throws OWLException {
		loader.setLoadImports(loadImports);
		if (refreshOnt) refreshOntology();
	}
	
	public void refresh() throws OWLException {
		Set loadedOnts = new HashSet( getLoadedOntologies() );
		clearOntologies();
		loadOntologies( loadedOnts );
	}
	
	/**
	 * @deprecated Use {@link #refresh()} instead
	 */
	public void refreshOntology() throws OWLException {
		refresh();		
	}
	
	/**
	 * @deprecated Use {@link #loadOntologies(Set)} instead
	 */
	public void setOntology(OWLOntology ontology) throws OWLException {
		clearOntologies();
		loadOntologies( Collections.singleton( ontology ) );
	}

	/** 
	 * @deprecated Use {@link #getOWLOntology()}
	 */
	public OWLOntology getOntology() {
		return null;
	}	

	/**
	 * Returns the set of all loaded ontologies.
	 * 
	 * @deprecated Use {@link #getLoadedOntologies()} instead
	 */
	public Set getOntologies() throws OWLException {
		return getLoadedOntologies();
	}
	
	public boolean isEntailed( OWLOntology ont ) throws OWLException {
		return isEntailed( ont.getAxioms() );
	}
	
	public boolean isEntailed( Set axioms ) throws OWLException {
		if( axioms.isEmpty() ) {
			log.warn( "Empty ontologies are entailed by any premise document!" );
		}
		else {
			EntailmentChecker entailmentChecker = new EntailmentChecker( this );
			for( Iterator i = axioms.iterator(); i.hasNext(); ) {
				OWLAxiom axiom = (OWLAxiom) i.next();
				
				if( !entailmentChecker.isEntailed( axiom ) ) {					
					log.warn("Axiom not entailed: (" + axiom + ")");
					return false;
				}
			}
		}
		
		return true;
	}
	
	/** 
	 * Use {@link #getSuperClasses(OWLDescription)}
	 * @deprecated
	 */
	public Set superClassesOf(OWLClass c) throws OWLException {
		return getSuperClasses( c );
	}
	
	/** 
	 * Use {@link #getSuperClasses(OWLDescription)}
	 * @deprecated
	 */
	public Set superClassesOf(OWLDescription c) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSuperClasses(loader.term(c), true), OWLClass.class);
	}
	
	public Set getSuperClasses(OWLDescription c) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSuperClasses(loader.term(c), true), OWLClass.class);
	}

	/**
	 * @deprecated Use {@link #getDescendantClasses(OWLDescription)} 
	 */
	public Set descendantClassesOf(OWLClass c) throws OWLException {
		return getDescendantClasses(c);
	}
	
	/**
	 * Use {@link #getDescendantClasses(OWLDescription)}
	 * @deprecated
	 */
	public Set descendantClassesOf(OWLDescription c) throws OWLException {
		return getDescendantClasses(c);
	}
	
	public Set getDescendantClasses(OWLDescription c) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSubClasses(loader.term(c)), OWLClass.class);
	}

	/**
	 * @deprecated Use {@link #getEquivalentClasses(OWLDescription)}
	 */
    public Set equivalentClassesOf(OWLClass c) throws OWLException {
    	return getEquivalentClasses(c);
    }
    
    /**
	 * @deprecated Use {@link #getEquivalentClasses(OWLDescription)}
	 */
	public Set equivalentClassesOf(OWLDescription c) throws OWLException {
		return toOWLEntitySet(kb.getEquivalentClasses(loader.term(c)), OWLClass.class);
	}
    
    public Set getEquivalentClasses(OWLDescription c) throws OWLException {
		return toOWLEntitySet(kb.getEquivalentClasses(loader.term(c)), OWLClass.class);
		
	}

    /**
     * @deprecated Use {@link #hasType(OWLIndividual, OWLDescription)} instead
     */
	public boolean isInstanceOf(OWLIndividual ind, OWLClass c) throws OWLException {
		return hasType(ind, c);
	}

	/**
     * @deprecated Use {@link #hasType(OWLIndividual, OWLDescription)} instead
     */
	public boolean isInstanceOf(OWLIndividual ind, OWLDescription d) throws OWLException {
		return hasType(ind, d);
	}
	
	/**
	 * Checks if the given individual is an instance of the given type
	 */
	public boolean hasType(OWLIndividual individual, OWLDescription type) throws OWLException {
		return kb.isType(loader.term(individual), loader.term(type));
	}
	
	/**
	 * @deprecated Use {@link #getIndividuals(OWLDescription, boolean)} with <code>false</code>
	 */
	public Set allInstancesOf(OWLClass c) throws OWLException {
		return toOWLEntitySet(kb.getInstances(loader.term(c)), OWLIndividual.class);
	}
	
	/**
	 * @deprecated Use {@link #getIndividuals(OWLDescription, boolean)} with <code>true</code>
	 */
	public Set instancesOf(OWLClass c) throws OWLException {
		return toOWLEntitySet(kb.getInstances(loader.term(c), true), OWLIndividual.class);
	}

	/**
	 * @deprecated Use {@link #getIndividuals(OWLDescription, boolean)} with <code>true</code>
	 */
	public Set instancesOf(OWLDescription d) throws OWLException {
		return toOWLEntitySet(kb.getInstances(loader.term(d)), OWLIndividual.class);
	}	
	

	/**
	 * Returns all or only direct instances of a concept expression
	 */
	public Set getIndividuals(OWLDescription clsC, boolean direct) throws OWLException {		
		return toOWLEntitySet(kb.getInstances(loader.term(clsC), direct), OWLIndividual.class);
	}
	
	/**
	 * 
	 * Return the set of all named classes defined in any of the ontologies loaded in the reasoner.
	 * 
	 * @return set of OWLClass objects
	 */
	public Set getClasses() {
		try {
			return toOWLEntitySet(kb.getClasses(), OWLClass.class);		
		} catch (OWLException e) {
			e.printStackTrace();
		}
		
		return Collections.EMPTY_SET;
	}
	

	/* (non-Javadoc)
	 * @see org.mindswap.swoop.SwoopReasoner#getProperties()
	 */
	public Set getProperties() {
		try {
			return toOWLEntitySet(kb.getProperties(), OWLProperty.class);
		} catch (OWLException e) {
			e.printStackTrace();
		}
		
		return Collections.EMPTY_SET;
	}

	public Set getObjectProperties() {
		Set set = new HashSet();
		Iterator props = getProperties().iterator();
		while(props.hasNext()) {
			OWLProperty prop = (OWLProperty) props.next();
			if(prop instanceof OWLObjectProperty)
				set.add(prop);
		}
		return set;
	}

    public boolean isInverseFunctional( OWLObjectProperty p ) throws OWLException {
        return kb.isInverseFunctionalProperty(loader.term(p));
    }

    public boolean isTransitive( OWLObjectProperty p ) throws OWLException {
        return kb.isTransitiveProperty(loader.term(p));
    }

    public boolean isSymmetric( OWLObjectProperty p ) throws OWLException {
        return kb.isSymmetricProperty(loader.term(p));
    }

    public boolean isReflexive( OWLObjectProperty p ) throws OWLException {
        return kb.isReflexiveProperty(loader.term(p));
    }

    public boolean isIrreflexive( OWLObjectProperty p ) throws OWLException {
        return kb.isIrreflexiveProperty(loader.term(p));
    }
	
	public Set getPropertyValues(OWLIndividual ind, OWLProperty prop) throws OWLException {
	    if( prop instanceof OWLObjectProperty )
	        return getRelatedIndividuals(ind, (OWLObjectProperty) prop);
	    else if( prop instanceof OWLDataProperty )
	        return getRelatedValues(ind, (OWLDataProperty) prop);
	    else
	        throw new OWLException("Property " + prop + " is neither data nor object property!");
	}
	
	/**
	 * @deprecated Use {@link #getObjectPropertyRelationships(OWLIndividual)} instead
	 */
	public Map getObjectPropertyValues(OWLIndividual ind) throws OWLException {
	    return getObjectPropertyRelationships(ind);
	}	
	
	public Map getPropertyValues(OWLObjectProperty prop) throws OWLException {
	    Map result = new HashMap();
	    ATermAppl p = loader.term(prop);
	    
	    Map values = kb.getPropertyValues( p );
        for(Iterator i = values.keySet().iterator(); i.hasNext();) {
            ATermAppl subjTerm = (ATermAppl) i.next();
            
            Collection objTerms = ((Collection) values.get( subjTerm ));
            
            OWLIndividual subj = (OWLIndividual)
	            getEntity( URI.create( subjTerm.getName() ), OWLIndividual.class );
            
	        Set objects = toOWLEntitySet( objTerms, OWLIndividual.class);
	        
	        result.put( subj, objects );
        } 
        
		return result;
	}
	
	public Map getPropertyValues(OWLDataProperty prop) throws OWLException {
	    Map map = new HashMap();
	    ATermAppl p = loader.term(prop);
        Collection candidates = kb.retrieveIndividualsWithProperty( p );
        for( Iterator i = candidates.iterator(); i.hasNext(); ) {
            ATermAppl candidate = (ATermAppl) i.next();
            List list = kb.getDataPropertyValues( p, candidate );
            if( list.isEmpty() )
                continue;
            
            OWLIndividual subj = (OWLIndividual)
                getEntity(URI.create(candidate.getName()), OWLIndividual.class);
            Set objects = toOWLEntitySet(list, OWLConstant.class);
            
            map.put( subj, objects );
        }  
        
		return map;
	}
	
	public Map getPropertyValues(OWLProperty prop) throws OWLException {
	    if( prop instanceof OWLObjectProperty )
	        return getPropertyValues((OWLObjectProperty) prop);
	    else if( prop instanceof OWLDataProperty )
	        return getPropertyValues((OWLDataProperty) prop);
	    else
	        throw new OWLException("Property " + prop + " is neither data nor object property!");
	}
	
	/**
	 * @deprecated Use {@link #hasObjectPropertyRelationship(OWLIndividual, OWLObjectPropertyExpression, OWLIndividual)} instead
	 */
	public boolean hasPropertyValue(OWLIndividual subj, OWLObjectProperty prop, OWLIndividual obj) throws OWLException {
		return hasObjectPropertyRelationship(subj, prop, obj);
	}
	
	/**
	 * @deprecated Use {@link #hasDataPropertyRelationship(OWLIndividual, OWLDataPropertyExpression, OWLConstant)} instead
	 */
	public boolean hasPropertyValue(OWLIndividual subj, OWLDataProperty prop, OWLConstant obj) throws OWLException {
		return hasDataPropertyRelationship(subj, prop, obj);
	}
	
	public boolean hasDataPropertyRelationship(OWLIndividual subject, OWLDataPropertyExpression property, OWLConstant object) throws OWLException {
		return kb.hasPropertyValue(loader.term(subject), loader.term(property), loader.term(object));
	}

	public boolean hasObjectPropertyRelationship(OWLIndividual subject, OWLObjectPropertyExpression property, OWLIndividual object) throws OWLException {
		return kb.hasPropertyValue(loader.term(subject), loader.term(property), loader.term(object));
	}
	
	public Set getDataProperties() {
		Set set = new HashSet();
		Iterator props = getProperties().iterator();
		while(props.hasNext()) {
			OWLProperty prop = (OWLProperty) props.next();
			if(prop instanceof OWLDataProperty)
				set.add(prop);
		}
		return set;
	}

	/* (non-Javadoc)
	 * @see org.mindswap.swoop.SwoopReasoner#getAnnotationProperties()
	 */
//	public Set getAnnotationProperties() {
//		Set set = new HashSet();
//		try {
//			Iterator ont = getOntologies().iterator();
//			while(ont.hasNext()) {
//				OWLOntology o = (OWLOntology) ont.next();
//				set.addAll(o.getAnnotationProperties());
//			}
//		} catch (OWLException e) {
//			e.printStackTrace();
//		}
//		return set;
//	}
	
	/**
	 * 
	 * Return the set of all individuals defined in any of the ontologies loaded in the reasoner.
	 * 
	 * @return set of OWLClass objects
	 */		
	public Set getIndividuals() {
		try {
			return toOWLEntitySet(kb.getIndividuals(), OWLIndividual.class);
		} catch (OWLException e) {
			e.printStackTrace();
		}
		
		return Collections.EMPTY_SET;
	}
	
	public OWLClass getClass(URI uri) throws OWLException {
		return (OWLClass) getEntity(uri, OWLClass.class);
	}
	
	public OWLObjectProperty getObjectProperty(URI uri) throws OWLException {
		return (OWLObjectProperty) getEntity(uri, OWLObjectProperty.class);
	}
	
	public OWLDataProperty getDataProperty(URI uri) throws OWLException {
		return (OWLDataProperty) getEntity(uri, OWLDataProperty.class);
	}
	
	public OWLIndividual getIndividual(URI uri) throws OWLException {
		return (OWLIndividual) getEntity(uri, OWLIndividual.class);
	}
	
	public OWLObject getEntity(URI uri, Class type) throws OWLException {
		OWLObject entity = null;
		Iterator i = getOntologies().iterator();
		while(entity == null && i.hasNext()) {
			OWLOntology o = (OWLOntology) i .next();
			if(entity == null && type.isAssignableFrom(OWLClass.class)) entity = manager.getOWLDataFactory().getOWLClass(uri);
			if(entity == null && type.isAssignableFrom(OWLDataType.class)) entity = manager.getOWLDataFactory().getOWLDataType(uri);
//			// XSD datatypes are not put into the ontology so previous statement returns null
//			// Let's check manually if the uri belongs to XSD and get the datatype object
//			// from the factory directly
//			if(entity == null && type.isAssignableFrom(OWLDataType.class) && XSD.getDatatypes().contains(uri.toString())) 
//				entity = manager.getOWLDataFactory().getOWLConcreteDataType(uri);
			if(entity == null && type.isAssignableFrom(OWLObjectProperty.class)) entity = manager.getOWLDataFactory().getOWLObjectProperty(uri);
			if(entity == null && type.isAssignableFrom(OWLDataProperty.class)) entity = manager.getOWLDataFactory().getOWLDataProperty(uri);
			if(entity == null && type.isAssignableFrom(OWLIndividual.class)) entity = manager.getOWLDataFactory().getOWLIndividual(uri);
//			if(entity == null && type.isAssignableFrom(OWLAnnotationProperty.class)) entity = manager.getOWLDataFactory().getOWLAnnotationProperty(uri);
		}
		
		return entity;
	}
	
	private Set toOWLEntitySetOfSet(Set set, Class type) throws OWLException {
		Set results = new HashSet();
		Iterator i = set.iterator();
		while(i.hasNext()) {
		    Set entitySet = toOWLEntitySet((Set) i.next(), type);
		    if(!entitySet.isEmpty())
		        results.add(entitySet);		
		}

		return results;		
	}	

	protected Set toOWLEntitySet(Collection set, Class type) throws OWLException {
		Set results = new HashSet();
		Iterator i = set.iterator();
		while(i.hasNext()) {
		    Object obj = i.next();
		    
			OWLObject e = null;
		    if(obj instanceof Role) {
				try {
					URI uri = new URI(((Role) obj).getName().getName());
			        e = getEntity(uri, type);
				} catch (URISyntaxException x) {
					throw new OWLException("Cannot create URI from term " + x);
				}		
		    }
		    else {
				ATermAppl term = (ATermAppl) obj;
				
				if(term.equals(ATermUtils.TOP))
					e = manager.getOWLDataFactory().getOWLThing();
				else if(term.equals(ATermUtils.BOTTOM))
					e = manager.getOWLDataFactory().getOWLNothing();
				else if(ATermUtils.isLiteral(term)) {
				    String value = ((ATermAppl) term.getArgument( 0 )).getName();
			        String lang = ((ATermAppl) term.getArgument( 1 )).getName();
			        String uri = ((ATermAppl) term.getArgument( 2 )).getName();			    
			        URI datatypeURI = uri.equals( "" ) ? null : URI.create( uri );

			        if( datatypeURI != null ) {
			        	OWLDataType datatype = manager.getOWLDataFactory().getOWLDataType( datatypeURI );
			            e =	manager.getOWLDataFactory().getOWLTypedConstant(value, datatype);
			        }
			        else if( lang.equals( "" ) )
			            e =	manager.getOWLDataFactory().getOWLUntypedConstant(value);
			        else
			            e =	manager.getOWLDataFactory().getOWLUntypedConstant(value, lang);
				}
				else if(term.getArity() == 0) {
					URI uri;
					try {
						uri = new URI(term.getName());
					} catch (URISyntaxException x) {
						throw new OWLException("Cannot create URI from term " + x);
					}		
					
					e = getEntity(uri, type);
				}
		    }
						
			if(e == null) continue;
			results.add(e);
		}

		return results;		
	}	

    public boolean isSubPropertyOf(OWLObjectProperty c1, OWLObjectProperty c2) throws OWLException {
        return kb.isSubPropertyOf(loader.term(c1), loader.term(c2));
    }
    
    public boolean isSubPropertyOf(OWLDataProperty c1, OWLDataProperty c2) throws OWLException {
        return kb.isSubPropertyOf(loader.term(c1), loader.term(c2));
    }

	public boolean isSubClassOf(OWLDescription c1, OWLDescription c2) throws OWLException {
		return kb.isSubClassOf(loader.term(c1), loader.term(c2));
	}
	
	public boolean isSubTypeOf(OWLDataType d1, OWLDataType d2) throws OWLException {
		return kb.isSubClassOf(loader.term(d1), loader.term(d2));
	}

	public boolean isEquivalentClass(OWLDescription c1, OWLDescription c2) throws OWLException {
		return kb.isEquivalentClass(loader.term(c1), loader.term(c2));
	}

    public boolean isComplementOf(OWLDescription c1, OWLDescription c2) throws OWLException {
        return kb.isComplement(loader.term(c1), loader.term(c2));
    }
    
    public boolean isDisjointWith(OWLDescription c1, OWLDescription c2) throws OWLException {
        return kb.isDisjointClass(loader.term(c1), loader.term(c2));
    }

    public boolean isDisjointWith(OWLObjectProperty p1, OWLObjectProperty p2) throws OWLException {
        return kb.isDisjointProperty(loader.term(p1), loader.term(p2));
    }

    public boolean isDisjointWith(OWLDataProperty p1, OWLDataProperty p2) throws OWLException {
        return kb.isDisjoint(loader.term(p1), loader.term(p2));
    }
    
    /**
     * @deprecated Use {@link #getDisjointClasses(OWLDescription)} instead
     */
    public Set disjointClassesOf( OWLDescription c ) throws OWLException {
        return toOWLEntitySetOfSet(kb.getDisjoints(loader.term(c)), OWLClass.class);
    }
    
    public Set getDisjointClasses( OWLDescription c ) throws OWLException {
        return toOWLEntitySetOfSet(kb.getDisjoints(loader.term(c)), OWLClass.class);
    }

    /**
     * @deprecated Use {@link #getComplementClasses(OWLDescription)}
     */
    public Set complementClassesOf( OWLDescription c ) throws OWLException {
    	return getComplementClasses( c );
    }
    
    public Set getComplementClasses(OWLDescription c) throws OWLException {
        return toOWLEntitySetOfSet(kb.getComplements(loader.term(c)), OWLClass.class);
    }

	/**
	 * Returns true if the loaded ontology is consistent. 
	 * 
	 * @param c
	 * @return
	 * @throws OWLException
	 */
	public boolean isConsistent() {
		return kb.isConsistent();
	}
	
	/**
	 * Returns true if the given class is consistent.
	 * 
	 * @param c
	 * @return
	 * @throws OWLException
	 */
	public boolean isConsistent(OWLDescription d) throws OWLException {
		if (!kb.isConsistent()) return false;
		try {
			return kb.isSatisfiable(loader.term(d));
		} catch (Exception e) {
		    e.printStackTrace();
			throw new OWLException(e.getMessage());
		}
	}

	/**
	 * Use {@link #getAncestorClasses(OWLDescription)}
	 * 
	 * @deprecated
	 */
	public Set ancestorClassesOf(OWLDescription c) throws OWLException {
		return getAncestorClasses( c );
	}	

	/**
	 * Use {@link #getAncestorClasses(OWLDescription)}
	 * 
	 * @deprecated
	 */
	public Set ancestorClassesOf(OWLClass c) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSuperClasses(loader.term(c)), OWLClass.class);
	}
	
	public Set getAncestorClasses(OWLDescription c) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSuperClasses(loader.term(c)), OWLClass.class);
	}

	/**
	 * Use {@link #getSubClasses(OWLDescription)}
	 * 
	 * @deprecated
	 */
	public Set subClassesOf(OWLDescription c) throws OWLException {
		return getSubClasses(c);
	}

	/**
	 * Use {@link #getSubClasses(OWLDescription)}
	 * @deprecated
	 */
	public Set subClassesOf(OWLClass c) throws OWLException {
		return getSubClasses(c);
	}
	
	public Set getSubClasses(OWLDescription c) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSubClasses(loader.term(c), true), OWLClass.class);
	}	
	
	/**
	 * @return Returns the autoClassify.
	 */
	public boolean isAutoClassify() {
		return autoClassify;
	}

	/**
	 * @param autoClassify The autoClassify to set.
	 */
	public void setAutoClassify(boolean autoClassify) {
		this.autoClassify = autoClassify;
	}

	/**
	 * @return Returns the autoRealize.
	 */
	public boolean isAutoRealize() {
		return autoRealize;
	}

	/**
	 * @param autoRealize The autoRealize to set.
	 */
	public void setAutoRealize(boolean autoRealize) {
		this.autoRealize = autoRealize;
	}

	/**
	 * @return Returns the kb.
	 */
	public KnowledgeBase getKB() {
		return kb;
	}
	
	/**
	 * Use {@link #getSuperProperties(OWLObjectProperty)}
	 * @deprecated
	 */
	public Set superPropertiesOf(OWLProperty p) throws OWLException {
		if( p instanceof OWLObjectProperty )
			return getSuperProperties( (OWLObjectProperty) p );
		else if( p instanceof OWLDataProperty )
			return getSuperProperties( (OWLDataProperty) p );
		
		throw new OWLException( p + " is not an Object or Data property" );
	}
	
	public Set getSuperProperties(OWLObjectProperty p) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSuperProperties(loader.term(p), true), OWLProperty.class);
	}

	public Set getSuperProperties(OWLDataProperty p) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSuperProperties(loader.term(p), true), OWLProperty.class);	
	}

	/**
	 * Use {@link #getAncestorProperties(OWLObjectProperty)}
	 * @deprecated
	 */
	public Set ancestorPropertiesOf(OWLProperty p) throws OWLException {
		if( p instanceof OWLObjectProperty )
			return getAncestorProperties( (OWLObjectProperty) p );
		else if( p instanceof OWLDataProperty )
			return getAncestorProperties( (OWLDataProperty) p );
		
		throw new OWLException( p + " is not an Object or Data property" );
	}

	public Set getAncestorProperties(OWLObjectProperty p) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSuperProperties(loader.term(p)), OWLProperty.class);
	}

	public Set getAncestorProperties(OWLDataProperty p) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSuperProperties(loader.term(p)), OWLProperty.class);
	}

	/**
	 * Use {@link #getSubProperties(OWLObjectProperty)}
	 * @deprecated
	 */
	public Set subPropertiesOf(OWLProperty p) throws OWLException {
		if( p instanceof OWLObjectProperty )
			return getSubProperties( (OWLObjectProperty) p );
		else if( p instanceof OWLDataProperty )
			return getSubProperties( (OWLDataProperty) p );
		
		throw new OWLException( p + " is not an Object or Data property" );
	}
	
	public Set getSubProperties(OWLDataProperty p) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSubProperties(loader.term(p), true), OWLProperty.class);
	}

	public Set getSubProperties(OWLObjectProperty p) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSubProperties(loader.term(p), true), OWLProperty.class);
	}

	/**
	 * @deprecated Use {@link #getDescendantSubProperties(OWLDataProperty)}
	 */
	public Set descendantPropertiesOf(OWLProperty p) throws OWLException {
		if( p instanceof OWLObjectProperty )
			return getDescendantProperties( (OWLObjectProperty) p );
		else if( p instanceof OWLDataProperty )
			return getDescendantProperties( (OWLDataProperty) p );
		
		throw new OWLException( p + " is not an Object or Data property" );
	}
	
	public Set getDescendantProperties(OWLDataProperty p) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSubProperties(loader.term(p), true), OWLProperty.class);
	}

	public Set getDescendantProperties(OWLObjectProperty p) throws OWLException {
		return toOWLEntitySetOfSet(kb.getSubProperties(loader.term(p), true), OWLProperty.class);
	}

	/**
	 * @deprecated Use {@link #getEquivalentProperties(OWLProperty)} instead
	 */
	public Set equivalentPropertiesOf(OWLProperty p) throws OWLException {
		return getEquivalentProperties( p );
	}
	
	public Set getEquivalentProperties(OWLProperty p) throws OWLException {
		if( p instanceof OWLObjectProperty )
			return getEquivalentProperties( (OWLObjectProperty) p );
		else if( p instanceof OWLDataProperty )
			return getEquivalentProperties( (OWLDataProperty) p );
		
		throw new OWLException( p + " is not an Object or Data property" );
	}

	public Set getEquivalentProperties(OWLObjectProperty p) throws OWLException {
		return toOWLEntitySet(kb.getEquivalentProperties(loader.term(p)), OWLProperty.class);
	}	

	public boolean isEquivalentProperty(OWLObjectProperty p1, OWLObjectProperty p2) throws OWLException {
		return kb.isEquivalentProperty(loader.term(p1), loader.term(p2));
	}

	public Set getEquivalentProperties(OWLDataProperty p) throws OWLException {
		return toOWLEntitySet(kb.getEquivalentProperties(loader.term(p)), OWLProperty.class);
	}

	public boolean isEquivalentProperty(OWLDataProperty p1, OWLDataProperty p2) throws OWLException {
		return kb.isEquivalentProperty(loader.term(p1), loader.term(p2));
	}
	
	/**
	 * @deprecated Use {@link #getInverseProperties(OWLObjectProperty)} instead
	 */
	public Set inversePropertiesOf(OWLObjectProperty prop) throws OWLException {
		return getInverseProperties( prop );
	}
	
	public Set getInverseProperties(OWLObjectProperty prop) throws OWLException {
		return toOWLEntitySet(kb.getInverses(loader.term(prop)), OWLProperty.class);
	}	

	/**
	 * Use {@link #getRanges(OWLObjectProperty)}
	 * @deprecated
	 */
	public Set rangesOf(OWLProperty p) throws OWLException {
		if( p instanceof OWLObjectProperty )
			return getRanges( (OWLObjectProperty) p );
		else if( p instanceof OWLDataProperty )
			return getRanges( (OWLDataProperty) p );
		
		throw new OWLException( p + " is not an Object or Data property" );
	}
	
	public Set getRanges(OWLObjectProperty p) throws OWLException {
		return toOWLEntitySet(kb.getRanges(loader.term(p)), OWLClass.class);
	}

	public Set getRanges(OWLDataProperty p) throws OWLException {
		return toOWLEntitySet(kb.getRanges(loader.term(p)), OWLDataType.class);
	}
	
	public boolean hasRange(OWLObjectProperty p, OWLDescription c) throws OWLException {
        return kb.hasRange(loader.term(p), loader.term(c));
	}
	
	public boolean hasRange(OWLDataProperty p, OWLDataRange d) throws OWLException {
        return kb.hasRange(loader.term(p), loader.term(d));
	}

	/**
	 * Use {@link #getDomains(OWLObjectProperty)}
	 * @deprecated
	 */
	public Set domainsOf(OWLProperty p) throws OWLException {
		if( p instanceof OWLObjectProperty )
			return getDomains( (OWLObjectProperty) p );
		else if( p instanceof OWLDataProperty )
			return getDomains( (OWLDataProperty) p );
		
		throw new OWLException( p + " is not an Object or Data property" );
	}
	
	public Set getDomains(OWLObjectProperty p) throws OWLException {
        return toOWLEntitySet(kb.getDomains(loader.term(p)), OWLClass.class);
	}
	
	public boolean hasDomain(OWLObjectProperty p, OWLDescription c) throws OWLException {
        return kb.hasDomain(loader.term(p), loader.term(c));
	}

	public Set getDomains(OWLDataProperty p) throws OWLException {
        return toOWLEntitySet(kb.getDomains(loader.term(p)), OWLClass.class);
	}
	
	public boolean hasDomain(OWLDataProperty p, OWLDescription c) throws OWLException {
        return kb.hasDomain(loader.term(p), loader.term(c));
	}

	/**
	 * @deprecated Use {@link #getType(OWLIndividual)} instead
	 */
	public OWLClass typeOf(OWLIndividual ind) throws OWLException {
		return getType(ind);
	}
	
	/**
	 * 
	 * Return the named class that this individual is a direct type of. If there is more than 
	 * one such class first one is returned.
	 * 
	 * @param ind
	 * @return OWLClass
	 * @throws OWLException
	 */
	public OWLClass getType(OWLIndividual ind) throws OWLException {
	    Set types = getTypes(ind);
	    
	    // this is a set of sets so get the first set
	    types = types.isEmpty() ? types : (Set) types.iterator().next();
	    
		return types.isEmpty() ? null : (OWLClass) types.iterator().next();
	}
	
	/**	 
	 * @deprecated Use {@link #getTypes(OWLIndividual, boolean)} with <code>true</code>
	 */
	public Set typesOf(OWLIndividual ind) throws OWLException {
		return getTypes(ind);
	}

	/**	 
	 * @deprecated Use {@link #getTypes(OWLIndividual, boolean)} with <code>false</code>
	 */
	public Set allTypesOf(OWLIndividual ind) throws OWLException {
		return toOWLEntitySetOfSet(kb.getTypes(loader.term(ind)), OWLClass.class);
	}
	
	/**
	 * 
	 * Returns all the named classes that this individual belongs. This returns a set of
	 * sets where each set is an equivalent class
	 * 
	 * @param ind
	 * @return Set of OWLDescription objects
	 * @throws OWLException
	 */
	public Set getTypes(OWLIndividual ind, boolean direct) throws OWLException {
		return toOWLEntitySetOfSet(kb.getTypes(loader.term(ind), direct), OWLClass.class);
	}
	
	/**
	 * Return a set of sameAs individuals given a specific individual
	 * based on axioms in the ontology
	 * @param ind - specific individual to test
	 * @return
	 * @throws OWLException
	 */
	public Set getSameAsIndividuals(OWLIndividual ind) throws OWLException {
	    return toOWLEntitySet(kb.getSames(loader.term(ind)), OWLIndividual.class);
	}	

    /**
     * Test if two individuals are owl:DifferentFrom each other.
     * 
     * @return
     * @throws OWLException
     */
    public boolean isSameAs(OWLIndividual ind1, OWLIndividual ind2) throws OWLException {
        return kb.isSameAs(loader.term(ind1),loader.term(ind2));
    }

    public Set getDifferentFromIndividuals(OWLIndividual ind) throws OWLException {
        return toOWLEntitySet(kb.getDifferents(loader.term(ind)), OWLIndividual.class);
    }
    
    /**
     * Test if two individuals are owl:DifferentFrom each other.
     * 
     * @return
     * @throws OWLException
     */
    public boolean isDifferentFrom(OWLIndividual ind1, OWLIndividual ind2) throws OWLException {
        return kb.isDifferentFrom(loader.term(ind1),loader.term(ind2));
    }

	public boolean isConsistent(OWLOntology ontology) throws OWLException {
		setOntology( ontology );
		
		return isConsistent();
	}

	public void dispose() throws OWLException {
		kb = null;
	}
		
	/**
	 * @deprecated Use {@link #getDataPropertyRelationships(OWLIndividual)} instead
	 */
	public Map getDataPropertyValues(OWLIndividual ind) throws OWLException {
	    return getDataPropertyRelationships( ind );
	}

	public Map getDataPropertyRelationships(OWLIndividual individual) throws OWLException {
	    Map values = new HashMap();
	    Set dataProps = getDataProperties();
	    for(Iterator i = dataProps.iterator(); i.hasNext();) {
            OWLDataProperty prop = (OWLDataProperty) i.next();
            Set set = getPropertyValues( individual, prop );
            if( !set.isEmpty() )
                values.put( prop, set );
        }
	    
	    return values;
	}

	public Set getRelatedValues(OWLIndividual subject, OWLDataPropertyExpression property) throws OWLException {
		return toOWLEntitySet(kb.getDataPropertyValues(loader.term(property), loader.term(subject)), OWLConstant.class);
	}
	
	public OWLConstant getRelatedValue(OWLIndividual subject, OWLDataPropertyExpression property) throws OWLException {
		Set values = getRelatedValues(subject, property);
		return values.isEmpty() ? null : (OWLConstant) values.iterator().next();
	}
			
	/**
	 * @deprecated Use {@link #getRelatedValues(OWLIndividual, OWLDataPropertyExpression)} instead
	 */
	public Set getPropertyValues(OWLIndividual ind, OWLDataProperty prop) throws OWLException {
		return getRelatedValues( ind, prop );
	}
	
	/**
	 * @deprecated Use {@link #getRelatedValue(OWLIndividual, OWLDataPropertyExpression)} instead
	 */
	public OWLConstant getPropertyValue(OWLIndividual ind, OWLDataProperty prop) throws OWLException {
		return getRelatedValue( ind, prop );
	}

	public Map getObjectPropertyRelationships(OWLIndividual individual) throws OWLException {
	    Map values = new HashMap();
	    Set objProps = getObjectProperties();
	    for(Iterator i = objProps.iterator(); i.hasNext();) {
            OWLObjectProperty prop = (OWLObjectProperty) i.next();
            Set set = getPropertyValues( individual, prop );
            if( !set.isEmpty() )
                values.put( prop, set );
        }
	    
	    return values;
	}
	
	
	public Set getRelatedIndividuals(OWLIndividual subject, OWLObjectPropertyExpression property) throws OWLException {
		return toOWLEntitySet( kb.getObjectPropertyValues(loader.term(property), loader.term(subject)), OWLIndividual.class);
	}
	
	public OWLIndividual getRelatedIndividual(OWLIndividual subject, OWLObjectPropertyExpression property) throws OWLException {
		Set values = getRelatedIndividuals(subject, property);
		return values.isEmpty() ? null : (OWLIndividual) values.iterator().next();
	}
	
	/**
	 * @deprecated Use {@link #getRelatedIndividuals(OWLIndividual, OWLObjectPropertyExpression)} instead
	 */
	public Set getPropertyValues(OWLIndividual ind, OWLObjectProperty prop) throws OWLException {
		return getRelatedIndividuals(ind, prop);
	}
	
	/**
	 * @deprecated Use {@link #getRelatedIndividual(OWLIndividual, OWLObjectPropertyExpression)} insteead
	 */
	public OWLIndividual getPropertyValue(OWLIndividual ind, OWLObjectProperty prop) throws OWLException {
		return getRelatedIndividual(ind, prop);
	}

	public Set getTypes(OWLIndividual individual) throws OWLException {
		return toOWLEntitySetOfSet(kb.getTypes(loader.term(individual), true), OWLClass.class);
	}

	public boolean isAntiSymmetric(OWLObjectProperty p) throws OWLException {
		return kb.isAntisymmetricProperty(loader.term(p));
	}

	public boolean isFunctional(OWLObjectProperty p) throws OWLException {
		return kb.isFunctionalProperty(loader.term(p));
	}

	public boolean isFunctional(OWLDataProperty p) throws OWLException {
		return kb.isFunctionalProperty(loader.term(p));
	}

	/**
	 * Listens to ontology changes and refreshes the underlying KB. Currently
	 * a full reload is applied.
	 */
	public void ontologiesChanged(List changes) throws OWLException {
		refresh();
	}

	public Set getInconsistentClasses() throws OWLException {		
		return toOWLEntitySet( kb.getSubClasses( ATermUtils.BOTTOM ), OWLClass.class );
	}

	public void clearOntologies() throws OWLException {
		loader.clear();
	}

	public Set getLoadedOntologies() throws OWLException {
		return loader.getOntologies();
	}

	public void loadOntologies(OWLOntology ontology) throws OWLException {
		loadOntologies( Collections.singleton( ontology ) );
	}
	
	public void loadOntologies(Set ontologies) throws OWLException {
		for( Iterator i = ontologies.iterator(); i.hasNext(); ) {
			OWLOntology ontology = (OWLOntology) i.next();
			loader.load( ontology, manager );
		}
		
		if( autoRealize )
			kb.realize();
		else if( autoClassify )
			kb.classify();
	}

	public void unloadOntologies(Set ontologies) throws OWLException {
		Set loadedOnts = new HashSet( getLoadedOntologies() );
		loadedOnts.removeAll( ontologies );
		
		clearOntologies();
		loadOntologies( ontologies );
	}
}
