// The MIT License
//
// Copyright (c) 2003 Ron Alford, Mike Grove, Bijan Parsia, Evren Sirin
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

package org.mindswap.pellet.owlapi;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.mindswap.pellet.KnowledgeBase;
import org.mindswap.pellet.utils.URIUtils;
import org.semanticweb.owl.model.OWLException;
import org.semanticweb.owl.model.OWLObject;
import org.semanticweb.owl.model.OWLOntology;
import org.semanticweb.owl.model.OWLOntologyManager;
import org.semanticweb.owl.vocab.Namespaces;

import aterm.ATermAppl;

public class PelletLoader {
	private KnowledgeBase	kb;

	private Set				loadedFiles;
	private boolean			loadImports	= true;

	private Set				ontologies;

	private PelletVisitor	visitor		= new PelletVisitor( kb );

	public PelletLoader(KnowledgeBase kb) {
		this.kb = kb;

		clear();
	}

	/**
	 * @return Returns the useImports.
	 */
	public boolean loadImports() {
		return loadImports;
	}

	/**
	 * @param useImports The useImports to set.
	 */
	public void setLoadImports(boolean loadImports) {
		this.loadImports = loadImports;
	}

	public void clear() {
		kb.clear();
		ontologies = new HashSet();
		loadedFiles = new HashSet();
		loadedFiles.add( Namespaces.OWL );
		loadedFiles.add( Namespaces.RDF );
		loadedFiles.add( Namespaces.RDFS );
	}

	public void load( OWLOntology ontology, OWLOntologyManager manager ) throws OWLException {
		if( loadImports && manager != null ) {
			Iterator i = manager.getImportsClosure( ontology ).iterator();
			while( i.hasNext() )
				loadOntology( (OWLOntology) i.next() );
		}
		else
			loadOntology( ontology );
	}

	public KnowledgeBase getKB() {
		return kb;
	}

	public void setKB(KnowledgeBase kb) {
		this.kb = kb;
	}

	public ATermAppl term(OWLObject d) throws OWLException {
		visitor.reset();
		d.accept( visitor );

		ATermAppl a = visitor.result();

		if( a == null )
			throw new OWLException( "Cannot create ATerm from description " + d );

		return a;
	}

	void loadOntology(OWLOntology ontology) throws OWLException {
		String uri = URIUtils.getNameSpace( ontology.getURI() );
		if( loadedFiles.contains( uri ) )
			return;
		loadedFiles.add( uri );
		ontologies.add( ontology );

		visitor = new PelletVisitor( kb );
		ontology.accept( visitor );
	}

	/**
	 * @return Returns the ontologies.
	 */
	public Set getOntologies() {
		return Collections.unmodifiableSet( ontologies );
	}

}
