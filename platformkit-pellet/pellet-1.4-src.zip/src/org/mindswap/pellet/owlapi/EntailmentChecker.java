package org.mindswap.pellet.owlapi;

import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.semanticweb.owl.model.OWLAntiSymmetricObjectPropertyAxiom;
import org.semanticweb.owl.model.OWLAxiom;
import org.semanticweb.owl.model.OWLAxiomAnnotationAxiom;
import org.semanticweb.owl.model.OWLAxiomVisitor;
import org.semanticweb.owl.model.OWLClassAssertionAxiom;
import org.semanticweb.owl.model.OWLConstant;
import org.semanticweb.owl.model.OWLDataProperty;
import org.semanticweb.owl.model.OWLDataPropertyAssertionAxiom;
import org.semanticweb.owl.model.OWLDataPropertyDomainAxiom;
import org.semanticweb.owl.model.OWLDataPropertyExpression;
import org.semanticweb.owl.model.OWLDataPropertyRangeAxiom;
import org.semanticweb.owl.model.OWLDataRange;
import org.semanticweb.owl.model.OWLDataSubPropertyAxiom;
import org.semanticweb.owl.model.OWLDeclarationAxiom;
import org.semanticweb.owl.model.OWLDescription;
import org.semanticweb.owl.model.OWLDifferentIndividualsAxiom;
import org.semanticweb.owl.model.OWLDisjointClassesAxiom;
import org.semanticweb.owl.model.OWLDisjointDataPropertiesAxiom;
import org.semanticweb.owl.model.OWLDisjointObjectPropertiesAxiom;
import org.semanticweb.owl.model.OWLDisjointUnionAxiom;
import org.semanticweb.owl.model.OWLEntityAnnotationAxiom;
import org.semanticweb.owl.model.OWLEquivalentClassesAxiom;
import org.semanticweb.owl.model.OWLEquivalentDataPropertiesAxiom;
import org.semanticweb.owl.model.OWLEquivalentObjectPropertiesAxiom;
import org.semanticweb.owl.model.OWLException;
import org.semanticweb.owl.model.OWLFunctionalDataPropertyAxiom;
import org.semanticweb.owl.model.OWLFunctionalObjectPropertyAxiom;
import org.semanticweb.owl.model.OWLImportsDeclaration;
import org.semanticweb.owl.model.OWLIndividual;
import org.semanticweb.owl.model.OWLInverseFunctionalObjectPropertyAxiom;
import org.semanticweb.owl.model.OWLInverseObjectPropertiesAxiom;
import org.semanticweb.owl.model.OWLIrreflexiveObjectPropertyAxiom;
import org.semanticweb.owl.model.OWLNegativeDataPropertyAssertionAxiom;
import org.semanticweb.owl.model.OWLNegativeObjectPropertyAssertionAxiom;
import org.semanticweb.owl.model.OWLObjectProperty;
import org.semanticweb.owl.model.OWLObjectPropertyAssertionAxiom;
import org.semanticweb.owl.model.OWLObjectPropertyChainSubPropertyAxiom;
import org.semanticweb.owl.model.OWLObjectPropertyDomainAxiom;
import org.semanticweb.owl.model.OWLObjectPropertyExpression;
import org.semanticweb.owl.model.OWLObjectPropertyInverse;
import org.semanticweb.owl.model.OWLObjectPropertyRangeAxiom;
import org.semanticweb.owl.model.OWLObjectSubPropertyAxiom;
import org.semanticweb.owl.model.OWLOntologyAnnotationAxiom;
import org.semanticweb.owl.model.OWLPropertyExpression;
import org.semanticweb.owl.model.OWLReflexiveObjectPropertyAxiom;
import org.semanticweb.owl.model.OWLSameIndividualsAxiom;
import org.semanticweb.owl.model.OWLSubClassAxiom;
import org.semanticweb.owl.model.OWLSymmetricObjectPropertyAxiom;
import org.semanticweb.owl.model.OWLTransitiveObjectPropertyAxiom;
import org.semanticweb.owl.model.SWRLRule;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Clark & Parsia, LLC. <http://www.clarkparsia.com></p>
 *
 * @author Evren Sirin
 */
public class EntailmentChecker implements OWLAxiomVisitor {
    public static Log log = LogFactory.getLog( EntailmentChecker.class );
   
	private Reasoner reasoner;
	private boolean isEntailed = false;
	
	public EntailmentChecker( Reasoner reasoner ) {
		this.reasoner = reasoner;
	}
	
	public boolean isEntailed( OWLAxiom axiom ) throws OWLException {
		isEntailed = false;
		
		axiom.accept( this );
		
		return isEntailed;
	}
	
	private OWLObjectProperty _getProperty( OWLObjectPropertyExpression pe ) throws OWLException {
		while( pe.isAnonymous() ) 
			pe = ((OWLObjectPropertyInverse) pe).getInverse();		
		
		return (OWLObjectProperty) pe;
	}
	
	private OWLPropertyExpression _normalize( OWLPropertyExpression pe ) throws OWLException {
		OWLPropertyExpression inverse = null;
		boolean returnInv = false;
		
		while( pe.isAnonymous() ) {
			inverse = pe;
			pe = ((OWLObjectPropertyInverse) pe).getInverse();
			returnInv = !returnInv;
		}
		
		return returnInv ? inverse : pe;
	}

	public void visit(OWLSubClassAxiom axiom) throws OWLException {
		isEntailed = reasoner.isSubClassOf( axiom.getSubClass(), axiom.getSuperClass() );
	}

	public void visit(OWLNegativeObjectPropertyAssertionAxiom axiom) throws OWLException {
		// TODO Auto-generated method stub

	}

	public void visit(OWLAntiSymmetricObjectPropertyAxiom axiom) throws OWLException {
		isEntailed = reasoner.isAntiSymmetric( (OWLObjectProperty) axiom.getProperty()  );
	}

	public void visit(OWLReflexiveObjectPropertyAxiom axiom) throws OWLException {
		isEntailed = reasoner.isReflexive( (OWLObjectProperty) axiom.getProperty() );
	}

	public void visit(OWLDisjointClassesAxiom axiom) throws OWLException {
		isEntailed = true;
		
		ArrayList list = new ArrayList( axiom.getDescriptions() );
		for( int i = 0; i < list.size() - 1; i++ ) {
			OWLDescription head = (OWLDescription) list.get( i );
			for( int j = i + 1; j < list.size() - 1; j++ ) {
				OWLDescription next = (OWLDescription) list.get( j );

				if( !reasoner.isDisjointWith( head, next ) ) {
					isEntailed = false;
					return;
				}
			}
		}
	}

	public void visit(OWLDataPropertyDomainAxiom axiom) throws OWLException {
		isEntailed = reasoner.hasDomain( (OWLDataProperty) axiom.getProperty(), axiom.getDomain() );
	}

	public void visit(OWLImportsDeclaration axiom) throws OWLException {
		isEntailed = true;
		if( log.isDebugEnabled() )
			log.debug( "Ignoring imports declaration " + axiom );
	}

	public void visit(OWLAxiomAnnotationAxiom axiom) throws OWLException {
		isEntailed = true;
		if( log.isDebugEnabled() )
			log.debug( "Ignoring axiom annotation " + axiom );
	}

	public void visit(OWLObjectPropertyDomainAxiom axiom) throws OWLException {
		isEntailed = reasoner.hasDomain( (OWLObjectProperty) axiom.getProperty(), axiom.getDomain() );
	}

	public void visit(OWLEquivalentObjectPropertiesAxiom axiom) throws OWLException {
		isEntailed = true;
		
		Iterator i = axiom.getProperties().iterator();
		if( i.hasNext() ) {
			OWLObjectProperty head = (OWLObjectProperty) i.next();

			while( i.hasNext() && isEntailed ) {		
				OWLObjectProperty next = (OWLObjectProperty) i.next();
				
				isEntailed = reasoner.isEquivalentProperty( head, next );
			}
		}
	}

	public void visit(OWLNegativeDataPropertyAssertionAxiom axiom) throws OWLException {
		// TODO Auto-generated method stub

	}

	public void visit(OWLDifferentIndividualsAxiom axiom) throws OWLException {
		isEntailed = true;
		
		ArrayList list = new ArrayList( axiom.getIndividuals() );
		for( int i = 0; i < list.size() - 1; i++ ) {
			OWLIndividual head = (OWLIndividual) list.get( i );
			for( int j = i + 1; j < list.size() - 1; j++ ) {
				OWLIndividual next = (OWLIndividual) list.get( j );
				
				if( !reasoner.isDifferentFrom( head, next ) ) {
					isEntailed = false;
					return;
				}
			}
		}
	}

	public void visit(OWLDisjointDataPropertiesAxiom axiom) throws OWLException {
		isEntailed = true;
		
		ArrayList list = new ArrayList( axiom.getProperties() );
		for( int i = 0; i < list.size() - 1; i++ ) {
			OWLDataProperty head = (OWLDataProperty) list.get( i );
			for( int j = i + 1; j < list.size() - 1; j++ ) {
				OWLDataProperty next = (OWLDataProperty) list.get( j );

				if( !reasoner.isDisjointWith( head, next ) ) {
					isEntailed = false;
					return;
				}
			}
		}
	}

	public void visit(OWLDisjointObjectPropertiesAxiom axiom) throws OWLException {
		isEntailed = true;
		
		ArrayList list = new ArrayList( axiom.getProperties() );
		for( int i = 0; i < list.size() - 1; i++ ) {
			OWLObjectProperty head = (OWLObjectProperty) list.get( i );
			for( int j = i + 1; j < list.size() - 1; j++ ) {
				OWLObjectProperty next = (OWLObjectProperty) list.get( j );

				if( !reasoner.isDisjointWith( head, next ) ) {
					isEntailed = false;
					return;
				}
			}
		}
	}

	public void visit(OWLObjectPropertyRangeAxiom axiom) throws OWLException {
		isEntailed = reasoner.hasRange( 
				(OWLObjectProperty) axiom.getProperty(), 
				(OWLDescription) axiom.getRange() );
	}

	public void visit(OWLObjectPropertyAssertionAxiom axiom) throws OWLException {
		isEntailed = reasoner.hasObjectPropertyRelationship( 
				axiom.getSubject(), 
				(OWLObjectPropertyExpression) axiom.getProperty(), 
				(OWLIndividual) axiom.getObject() );
	}

	public void visit(OWLFunctionalObjectPropertyAxiom axiom) throws OWLException {
		isEntailed = reasoner.isFunctional( (OWLObjectProperty) axiom.getProperty() );
	}

	public void visit(OWLObjectSubPropertyAxiom axiom) throws OWLException {
		isEntailed = reasoner.isSubPropertyOf( (OWLObjectProperty) axiom.getSubProperty(), (OWLObjectProperty) axiom.getSuperProperty() );
	}

	public void visit(OWLDisjointUnionAxiom axiom) throws OWLException {
		// TODO Auto-generated method stub

	}

	public void visit(OWLDeclarationAxiom axiom) throws OWLException {
		isEntailed = true;
		if( log.isDebugEnabled() )
			log.debug( "Ignoring declaration " + axiom );
	}

	public void visit(OWLEntityAnnotationAxiom axiom) throws OWLException {
		isEntailed = true;
		if( log.isDebugEnabled() )
			log.debug( "Ignoring entity annotation " + axiom );
	}

	public void visit(OWLOntologyAnnotationAxiom axiom) throws OWLException {
		isEntailed = true;
		if( log.isDebugEnabled() )
			log.debug( "Ignoring ontology annotation " + axiom );
	}

	public void visit(OWLSymmetricObjectPropertyAxiom axiom) throws OWLException {
		isEntailed = reasoner.isSymmetric( (OWLObjectProperty) axiom.getProperty() );
	}

	public void visit(OWLDataPropertyRangeAxiom axiom) throws OWLException {
		isEntailed = reasoner.hasRange( 
				(OWLDataProperty) axiom.getProperty(), 
				(OWLDataRange) axiom.getRange() );
	}

	public void visit(OWLFunctionalDataPropertyAxiom axiom) throws OWLException {
		isEntailed = reasoner.isFunctional( (OWLDataProperty) axiom.getProperty() );
	}

	public void visit(OWLEquivalentDataPropertiesAxiom axiom) throws OWLException {
		Iterator i = axiom.getProperties().iterator();
		if( i.hasNext() ) {
			OWLDataProperty head = (OWLDataProperty) i.next();

			while( i.hasNext() && isEntailed ) {		
				OWLDataProperty next = (OWLDataProperty) i.next();
				
				isEntailed = reasoner.isEquivalentProperty( head, next );
			}
		}
	}

	public void visit(OWLClassAssertionAxiom axiom) throws OWLException {
		OWLIndividual ind = axiom.getIndividual();
		OWLDescription c = axiom.getDescription();
		
		if( ind.isAnonymous() ) 
			isEntailed = reasoner.isConsistent( c );
		else
			isEntailed = reasoner.hasType( ind, c );
	}

	public void visit(OWLEquivalentClassesAxiom axiom) throws OWLException {
		isEntailed = true;
		
		Iterator i = axiom.getDescriptions().iterator();
		if( i.hasNext() ) {
			OWLDescription head = (OWLDescription) i.next();

			while( i.hasNext() && isEntailed ) {		
				OWLDescription next = (OWLDescription) i.next();
				
				isEntailed = reasoner.isEquivalentClass( head, next );
			}
		}
	}

	public void visit(OWLDataPropertyAssertionAxiom axiom) throws OWLException {
		isEntailed = reasoner.hasDataPropertyRelationship( 
				axiom.getSubject(), 
				(OWLDataPropertyExpression) axiom.getProperty(), 
				(OWLConstant) axiom.getObject() );
	}

	public void visit(OWLTransitiveObjectPropertyAxiom axiom) throws OWLException {
		isEntailed = reasoner.isTransitive( (OWLObjectProperty) axiom.getProperty() );
	}

	public void visit(OWLIrreflexiveObjectPropertyAxiom axiom) throws OWLException {
		isEntailed = reasoner.isIrreflexive( (OWLObjectProperty) axiom.getProperty() );
	}

	public void visit(OWLDataSubPropertyAxiom axiom) throws OWLException {
		isEntailed = reasoner.isSubPropertyOf( (OWLDataProperty) axiom.getSubProperty(), (OWLDataProperty) axiom.getSuperProperty() );
	}

	public void visit(OWLInverseFunctionalObjectPropertyAxiom axiom) throws OWLException {
		isEntailed = reasoner.isInverseFunctional( (OWLObjectProperty) axiom.getProperty() );
	}

	public void visit(OWLSameIndividualsAxiom axiom) throws OWLException {
		isEntailed = true;
		
		Iterator i = axiom.getIndividuals().iterator();
		if( i.hasNext() ) {
			OWLIndividual head = (OWLIndividual) i.next();

			while( i.hasNext() ) {
				OWLIndividual next = (OWLIndividual) i.next();
				
				if( !reasoner.isSameAs( head, next ) ) {
					isEntailed = false;
					return;
				}
			}
		}
	}

	public void visit(OWLObjectPropertyChainSubPropertyAxiom axiom) throws OWLException {
		// TODO Auto-generated method stub

	}

	public void visit(OWLInverseObjectPropertiesAxiom axiom) throws OWLException {
		isEntailed = reasoner.isSubPropertyOf( (OWLObjectProperty) axiom.getFirstProperty(), (OWLObjectProperty) axiom.getSecondProperty() );
	}

	public void visit(SWRLRule rule) throws OWLException {
		// TODO Auto-generated method stub

	}

}
