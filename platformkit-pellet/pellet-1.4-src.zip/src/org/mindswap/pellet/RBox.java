// The MIT License
//
// Copyright (c) 2003 Ron Alford, Mike Grove, Bijan Parsia, Evren Sirin
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

package org.mindswap.pellet;


import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mindswap.pellet.taxonomy.Taxonomy;
import org.mindswap.pellet.utils.ATermUtils;
import org.mindswap.pellet.utils.Pair;
import org.mindswap.pellet.utils.fsm.State;
import org.mindswap.pellet.utils.fsm.TransitionGraph;

import aterm.ATerm;
import aterm.ATermAppl;
import aterm.ATermList;

public class RBox {
    public static Log log = LogFactory.getLog( RBox.class );

	private Map roles = new HashMap();
	private Set reflexiveRoles = new HashSet();	
	
	private Taxonomy taxonomy;
	
    /**
     * @deprecated Simply ignore invalid statements
     */
	boolean consistent = true;  

	public RBox() {
	}

	/**
	 * Return the role with the given name
	 * 
	 * @param r Name (URI) of the role
	 * @return
	 */
	public Role getRole(ATerm r) {
		return (Role) roles.get(r);
	}
	
	/**
	 * Return the role with the given name and throw and exception
	 * if it is not found.
	 * 
	 * @param r Name (URI) of the role
	 * @return
	 */
	public Role getDefinedRole(ATerm r) {
		Role role = (Role) roles.get(r);
		
		if(role == null)
			throw new RuntimeException(r + " is not defined as a property");
		
		return role;
	}

    /**
     * @deprecated Inconsistent axioms are rejected
     */
	public boolean isConsistent() {
		return consistent;
	}

	public Role addRole( ATermAppl r ) {
		Role role = getRole( r );
		
		if(role == null) {
			role = new Role(r, Role.UNTYPED);
			roles.put(r, role);				
		}
		
		return role;
	}
	
	public Role addObjectRole( ATermAppl r ) {
		Role role = getRole(r);
		
		if(role == null) {
			role = new Role(r, Role.OBJECT);
			roles.put(r, role);			

			ATermAppl invR = ATermUtils.makeInv(r);
			Role invRole = new Role(invR, Role.OBJECT);
			roles.put(invR, invRole);			

			role.setInverse(invRole);
			invRole.setInverse(role);
		}
		else if(role.getType() == Role.UNTYPED) {
			role.setType(Role.OBJECT);

			ATermAppl invR = ATermUtils.makeInv(r);
			Role invRole = new Role(invR, Role.OBJECT);
			roles.put(invR, invRole);						

			role.setInverse(invRole);
			invRole.setInverse(role);
		}
		else if(role.getType() != Role.OBJECT && role.getType() != Role.ANNOTATION) {
		    role = null;    	
		}
		
		return role;
	}

	public Role addDatatypeRole(ATermAppl r) {
		Role role = getRole(r);
		
		if(role == null) {
			role = new Role(r, Role.DATATYPE);
			roles.put(r, role);			
		}
		else if(role.getType() == Role.UNTYPED) {
			role.setType(Role.DATATYPE);
		}
		else if(role.getType() != Role.DATATYPE && role.getType() != Role.ANNOTATION) {
			role = null;    	
		}
		
		return role;
	}
	
	//Added for E-connections	
	public Role addLinkRole(ATermAppl r) {
		Role role = getRole(r);
		
		if(role == null) {
			role = new Role(r, Role.LINK);
			roles.put(r, role);			
		}
		else if(role.getType() == Role.UNTYPED) {
			role.setType(Role.LINK);
		}
		else if(role.getType() != Role.LINK) {
			role = null;    	
		}
		
		return role;
	}	
	
	public Role addAnnotationRole(ATermAppl r) {
		Role role = getRole(r);
		
		if( role == null ) {
            role = new Role( r, Role.ANNOTATION );
            roles.put( r, role );
        }
        else if( role.getType() == Role.UNTYPED ) {
            role.setType( Role.ANNOTATION );
        }
        else if( role.getType() != Role.ANNOTATION ) {
        	//role.setType( Role.ANNOTATION );
        	role = new Role( r, Role.ANNOTATION );
            roles.put( r, role );
        }
		
		return role;
	}
	
	public Role addOntologyRole(ATermAppl r) {
		Role role = getRole(r);
		
		if(role == null) {
			role = new Role(r, Role.ONTOLOGY);
			roles.put(r, role);			
		}
        else if( role.getType() == Role.UNTYPED ) {
            role.setType( Role.ONTOLOGY );
        }
        else if( role.getType() != Role.ONTOLOGY ) {
            role = null;
        }
		
		return role;
	}
	
			
	public boolean addSubRole(ATerm sub, ATerm sup) {
		Role roleSup = getRole(sup);
        Role roleSub = getRole(sub);
        
		if( roleSup == null ) 
			return false;   			
        else if( sub.getType() == ATerm.LIST ) 
            roleSup.addSubRoleChain( (ATermList) sub );
        else if( roleSub == null ) 
            return false; 
        else {
    		roleSup.addSubRole(roleSub);
    		roleSub.addSuperRole(roleSup);
        }
        
        return true;
	}
	
    /**
     * @deprecated Use addEquivalentRole instead
     */
	public boolean addSameRole(ATerm s, ATerm r) {
        return addEquivalentRole(s, r);
    }
    
    public boolean addEquivalentRole(ATerm s, ATerm r) {
		Role roleS = getRole(s);
		Role roleR = getRole(r);
		
		if(roleS == null || roleR == null) 
			return false;     			
		
		roleR.addSubRole(roleS);
		roleR.addSuperRole(roleS);
		roleS.addSubRole(roleR);
		roleS.addSuperRole(roleR);
	
        return true;
	}
	
    public boolean addDisjointRole(ATerm s, ATerm r) {
        Role roleS = getRole(s);
        Role roleR = getRole(r);
        
        if(roleS == null || roleR == null) 
            return false;               
        
        roleR.addDisjointRole(roleS);
        roleS.addDisjointRole(roleR);
    
        return true;
    }
    
	public boolean addInverseRole(ATerm s, ATerm r) {
		Role roleS = getRole(s);
		Role roleR = getRole(r);
		
		if(roleS == null || roleR == null) 
			return false;     			
		else {
            boolean prevInvRisFunctional = roleR.getInverse().isFunctional();
            boolean prevInvSisFunctional = roleS.getInverse().isFunctional();
			ATermAppl prevInvR = roleR.getInverse().getName();
			ATermAppl prevInvS = roleS.getInverse().getName();
			
			//inverse relation already defined
			if(prevInvR.equals(s) && prevInvS.equals(r))
				return true;
				
			// this means r already has another inverse defined 
			if(prevInvR.getArity() == 0) {
				// this means s already has another inverse defined
				if(prevInvS.getArity() == 0) {
					// prevInvR = S and prenInvS = R
                    addEquivalentRole(prevInvR, s);
                    addEquivalentRole(prevInvS, r);
				}
				else {
					// Set prevInvR = S. we can get rid of prevInvS 
					// because it is not a named property
                    addEquivalentRole(prevInvR, s);
                    if( prevInvSisFunctional )
						roleR.setFunctional(true);
					roles.remove(prevInvS);
				}
			}
			else if(prevInvS.getArity() == 0) {
				// Set prevInvS = R. we can get rid of prevInvR 
				// because it is not a named property
                addEquivalentRole(prevInvS, r);
                roleR.setInverse(roleS);
				if( prevInvRisFunctional )
					roleS.setFunctional(true);
				roles.remove(prevInvR);			
            }
			else {
				roleR.setInverse(roleS);
				roleS.setInverse(roleR);
				if( prevInvRisFunctional )
                    roleS.setFunctional( true );
                if( prevInvSisFunctional )
                    roleR.setFunctional( true );
				roles.remove(prevInvR);
				roles.remove(prevInvS);
			}			
		}
        
        return true;
	}
				
	/**
	 * check if the term is declared as a role
	 */
	public boolean isRole( ATerm r ) {
	    return roles.containsKey( r );
	}
		
	public void prepare() {
		boolean hasComplexSubRoles = false;
		
        // first pass - compute sub roles
        Iterator i = roles.values().iterator();
        while( i.hasNext() ) {
            Role role = (Role) i.next();

            if( role.getType() == Role.OBJECT || role.getType() == Role.DATATYPE ) {
                Set subRoles = new HashSet();
                Set subRoleChains = new HashSet();
                hasComplexSubRoles |= role.hasComplexSubRole();
                computeSubRoles( role, subRoles, subRoleChains );
                role.setSubRoles( subRoles );
                role.setSubRoleChains( subRoleChains );             
            }
        }

        // second pass - set super roles and propagate domain & range
        i = roles.values().iterator();
        while( i.hasNext() ) {
            Role role = (Role) i.next();

            Role invR = role.getInverse();
            if( invR != null ) {
                // domain of inv role is the range of this role
                Set domains = invR.getDomains();
                if( domains != null ) role.addRanges( domains );
                Set ranges = invR.getRanges();
                if( ranges != null ) role.addDomains( ranges );

                if( invR.isTransitive() )
                    role.setTransitive( true );
                else if( role.isTransitive() )
                    invR.setTransitive( true );
                if( !invR.isSimple() )
                    role.setSimple( false );                
                else if( !role.isSimple() )
                    invR.setSimple( false );                
                if( invR.isFunctional() )
                    role.setInverseFunctional( true );
                if( role.isFunctional() ) 
                    invR.setInverseFunctional( true );
                if( invR.isInverseFunctional() )
                    role.setFunctional( true );
                if( invR.isAntisymmetric() ) 
                    role.setAntisymmetric( true );
                if( role.isAntisymmetric() ) 
                    invR.setAntisymmetric( true );
                if( invR.isReflexive() ) 
                    role.setReflexive( true );
                if( role.isReflexive() ) 
                    invR.setReflexive( true ); 
                if( invR.hasComplexSubRole() )
                	role.setHasComplexSubRole( true );
                if( role.hasComplexSubRole() )
                	invR.setHasComplexSubRole( true );
            }

            Set domains = role.getDomains();
            Set ranges = role.getRanges();
            Iterator subs = role.getSubRoles().iterator();
            while( subs.hasNext() ) {
                Role s = (Role) subs.next();
                s.addSuperRole( role );
                
                if( !s.isSimple() )
                    role.setSimple( false );    
                if( s.hasComplexSubRole() )
                	role.setHasComplexSubRole( true );
                if( domains != null )
                    s.addDomains( domains );
                if( ranges != null )
                    s.addRanges( ranges );
            }
        }
        
        // TODO propagate disjoint roles through sub/super roles
        
        // third pass - set transitivity and functionality
        i = roles.values().iterator();
        while( i.hasNext() ) {
            Role r = (Role) i.next();

            r.normalize();
                
            boolean isTransitive = r.isTransitive();
            Iterator subs = r.getSubRoles().iterator();
            while( subs.hasNext() ) {
                Role s = (Role) subs.next();
                if( s.isTransitive() ) {
                    if( r.isSubRoleOf( s ) ) 
                        isTransitive = true;
                    r.addTransitiveSubRole( s );
                }
            }
            r.setTransitive( isTransitive );                  

	        if( hasComplexSubRoles && !r.isSimple() ) 
				buildDFA( r );
			           
            Iterator supers = r.getSuperRoles().iterator();
            while( supers.hasNext() ) {
                Role s = (Role) supers.next();
                if( s.isFunctional() ) {
                    r.setFunctional( true );
                    r.addFunctionalSuper( s );
                }
                if( s.isIrreflexive() ) {
                    r.setIrreflexive( true );
                }
            }
           
            if( r.isReflexive() && !r.isAnon() )
                reflexiveRoles.add( r );
        }
        
        // we will compute the taxonomy when we need it
        taxonomy = null;
    }

	private Set computeImmediateSubRoles( Role r ) {
		Set subs = null;

		Role invR = r.getInverse();
		if(invR == null) {
		    subs = r.getSubRoles();
            subs.addAll( r.getSubRoleChains() );
        }
		else {
		    subs = new HashSet( r.getSubRoles() );
            subs.addAll( r.getSubRoleChains() );
            
		 	Iterator i = invR.getSubRoles().iterator();
		 	while(i.hasNext()) {
		 		Role invSubR =  (Role) i.next();
		 		Role subR = invSubR.getInverse();
                if( subR == null ) {
                    System.err.println( "Property " + invSubR
                        + " was supposed to be an ObjectProperty but it is not!" );
                }
                else {
                    subs.add( subR );
                }
		 	}
            i = invR.getSubRoleChains().iterator();
            while( i.hasNext() ) {
                ATermList roleChain = (ATermList) i.next();
                subs.add( inverse( roleChain ) );
            }
		}
		
		return subs;
	}

	private void computeSubRoles( Role r, Set subRoles, Set subRoleChains ) {
		// check for loops
		if(subRoles.contains(r))
			return;
	
		// reflexive	
		subRoles.add(r);
		
		// transitive closure		
		Iterator i = computeImmediateSubRoles(r).iterator(); 
		while(i.hasNext()) {
			Object sub = i.next();
            if( sub instanceof Role )
            	computeSubRoles( (Role) sub, subRoles, subRoleChains );
            else 
            	subRoleChains.add( sub );
		}
	}			

    private TransitionGraph buildDFA( Role s ) {
        TransitionGraph tg = s.getFSM();
        if( tg != null )
            return tg;
        
        if( log.isDebugEnabled() )
            log.debug( "Building NFA for " + s );
        
        tg = buildNFA( s );
        
        if( log.isDebugEnabled() )
            log.debug( "Determinize " + s  + ": " + tg.size() );
        
        tg.determinize();
        
//        ATermUtils.assertTrue( tg.isDeterministic() );
             
        if( log.isDebugEnabled() )
            log.debug( "Minimize NFA for " + s  + ": " + tg.size() );

        tg.minimize();
        
//        ATermUtils.assertTrue( tg.isDeterministic() );
        
        tg.renumber();
  
//        ATermUtils.assertTrue( tg.isDeterministic() );
        
        s.setFSM( tg );
        
        return tg;
    }
    
    private TransitionGraph buildNFA( Role s ) {       
        TransitionGraph tg = new TransitionGraph();                
        
        State i = tg.newState();
        State f = tg.newState();
        
        tg.setInitialState( i );
        tg.addFinalState( f );

        tg.addTransition( i, s, f );
        
        Set subRoles = s.getSubRoles();
        subRoles.remove( s );
        
        for( Iterator it = subRoles.iterator(); it.hasNext(); ) {
            Role sub = (Role) it.next();
            tg.addTransition( i, sub, f );
        }
        
        for( Iterator it = s.getSubRoleChains().iterator(); it.hasNext(); ) {
            ATermList subChain = (ATermList) it.next();
            addTransition( tg, s, subChain );
        }
                
        for( Iterator it = subRoles.iterator(); it.hasNext(); ) {
            Role r = (Role) it.next();
            
            addTransitions( tg, r );
        }
         
        return tg;
    }
    
    private void addTransition( TransitionGraph tg, Role s, ATermList chain ) {
        State first = tg.getInitialState(), last = tg.getFinalState();
        
        if( ATermUtils.isTransitiveChain( chain, s.getName() ) ) {
            tg.addTransition( last, first );
            return;
        }        
        else if( chain.getFirst().equals( s.getName() ) ) {
            chain = chain.getNext();
            first = tg.getFinalState();
        }
        else if( chain.getLast().equals( s.getName() ) ) {
            chain = chain.remove( s.getName() );
            last = tg.getInitialState();            
        }

        State next = tg.newState();
        tg.addTransition( first, next );
        first = next;
            
        for( ; !chain.isEmpty(); chain = chain.getNext() ) {         
            next = tg.newState();
            tg.addTransition( first, getRole( chain.getFirst() ), next );
            first = next;
        }
        
        tg.addTransition( first, last );
    }
    
    private void addTransitions( TransitionGraph tg, Role r ) {
        List pairs = tg.findTransitions( r );
        for( Iterator i = pairs.iterator(); i.hasNext(); ) {
            TransitionGraph newGraph = buildDFA( r ).copy();            
            
            Pair pair = (Pair) i.next();
         
            tg.insert( newGraph, (State) pair.first, (State) pair.second );           
        }
    }
    
	/**
	 * Returns a string representation of the RBox where for each role subroles,
	 * superroles, and isTransitive information is given
	 */	
	public String toString() {
		return "[RBox " + roles.values() + "]";
	}
	
	/**
	 * for each role in the list finds an inverse role and 
	 * returns the new list. 
	 */
	public ATermList inverse( ATermList roles ) {
		ATermList invList = ATermUtils.EMPTY_LIST;
	 	
	 	for( ATermList list = roles; !list.isEmpty(); list = list.getNext() ) {
            ATermAppl r = (ATermAppl) list.getFirst();
	 		Role role =  getRole( r );
	 		Role invR = role.getInverse();
	 		if(invR == null) {
	 			System.err.println("Property " + r + " was supposed to be an ObjectProperty but it is not!");
	 		}
	 		else
	 			invList = invList.insert( invR.getName() );
	 	}
		
		return invList;
   }	
	/**
	 * @return Returns the roles.
	 */
	public Set getRoleNames() {
		return roles.keySet();
	}

	public Set getReflexiveRoles() {
		return reflexiveRoles;
	}

    /**
     * getRoles
     * 
     * @return
     */
    public Collection getRoles() {
        return roles.values();
    }
    
    
    public Taxonomy getTaxonomy() {
        if( taxonomy == null ) {
	        RoleTaxonomyBuilder builder = new RoleTaxonomyBuilder( this );
	        taxonomy = builder.classify();
        }
        return taxonomy;
    }
    public RBox copy() {
        Iterator i = roles.keySet().iterator();
        Map newroles = new HashMap();
        Map conversion = new HashMap();
//        Set newFunctionalRoles = new HashSet();
        while(i.hasNext()) {
            ATermAppl key = (ATermAppl)i.next();
            Role r = (Role)roles.get(key);
            Role newr = r.copy(conversion);
            //Role newr;
            //if(conversion.containsKey(r)) {
            //    newr = (Role)conversion.get(r);
            //} else {
            //    newr = new Role(r.name);
            //    conversion.set(r, newr);
            //}
            newroles.put(key, newr);
//            if(functionalRoles.contains(r)) {
//                newFunctionalRoles.add(newr);
//            }
            // first, we need to copy all the easy stuff: foreignOnt,
            // name, type, domains, ranges, and the assorted booleans
            // BUGBUG

            // now we have to make sure the inverse, subRoles,
            // superRoles, functionalSupers, and transitiveRoles are
            // converted properly
            //if(!conversion.containsKey(r.inverse)) {
            //    conversion.set(r.inverse, Role(r.inverse.name));
            //}
            //newr.inverse = (Role)conversion.get(r.inverse);
            //newr.subRoles = roleSetCopy(r.subRoles, conversion);
            //newr.superRoles = roleSetCopy(r.superRoles, conversion);
            //newr.functionalSupers = roleSetCopy(r.functionalSupers, conversion);
            //newr.transitiveSubRoles = roleSetCopy(r.transitiveSubRoles, conversion); 
        }
        RBox newrbox = new RBox();
        newrbox.roles = newroles;
//        newrbox.functionalRoles = newFunctionalRoles;
        newrbox.taxonomy = null;
        newrbox.consistent = consistent;
        return newrbox;
    }
    //private Set roleSetCopy(Set roleset, Map conversion) {
    //    Set newroles = new HashSet();
    //    Iterator j = roleset.iterator();
    //    while(j.hasNext()) {
    //        Role role = (Role)j.next();
    //        if(!conversion.containsKey(role)) {
    //            conversion.set(role, new Role(role.name));
    //        }
    //        newroles.add((Role)conversion.get(role));
    //    }
    //    return newroles;
        
    //}
     
}
