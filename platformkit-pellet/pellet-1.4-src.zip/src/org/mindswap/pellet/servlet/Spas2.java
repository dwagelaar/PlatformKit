package org.mindswap.pellet.servlet;

import org.mindswap.pellet.utils.Timer;
import org.mindswap.pellet.utils.Timers;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;
import java.io.BufferedReader;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.LinkedList;
import java.util.List;
import java.util.Iterator;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mindswap.pellet.servlet.functions.IsCanonical;

import org.mindswap.pellet.jena.PelletReasonerFactory2;
import org.mindswap.pellet.jena.PelletInfGraph;
import org.mindswap.pellet.KnowledgeBase;
import org.mindswap.pellet.PelletOptions;

import com.hp.hpl.jena.query.Dataset;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.query.ResultSetFormatter;
import com.hp.hpl.jena.query.function.FunctionRegistry;
import com.hp.hpl.jena.rdf.model.Model;

import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.graph.compose.MultiUnion;
import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.mem.GraphMem;
import com.hp.hpl.jena.rdf.arp.JenaReader;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.ontology.OntDocumentManager;
import org.mindswap.pellet.jena.PelletReasonerFactory;

//since the pelletpool and q are shared between Spigot and
//Spas2, we need to lock each before working with it

// OK, so the plan is to create one jena union model, which will have
// all the rdf data.  We'll handle puts, deletes, and so on to this.
// We'll also have a pool of pellets that is reset every time the
// data changes.  We answer queries from that pool.  Eventually, we
// may try to serve up old results from the old pellet copies while
// we refill.

public class Spas2 extends HttpServlet {
    //Map contexts = null;
    PelletPool pelletpool = null;
    //BlockingQueue q = null;
    LinkedList q = null;
    public void init(ServletConfig config) {
        PelletOptions.REALIZE_INDIVIDUAL_AT_A_TIME = false;
        //model = new OntModel();
        //contexts = new HashMap();
        pelletpool = new PelletPool();
        q = new LinkedList();
        FunctionRegistry registry = FunctionRegistry.get();
        registry.put("http://www.mindswap.org/2005/sparql/reasoning#isCanonical", IsCanonical.class);
        // does spigot need to know about the contexts also?
        Spigot spigot = new Spigot(pelletpool, q);
        spigot.start();
    }
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //OutputStream out = response.getOutputStream();
        if(request.getParameterMap().containsKey("query")) {
            //String queryString = request.getParameter("query");
            //Query query = QueryFactory.create(queryString);
            // check out model, run query, return results
            OntModel model = null;
            while(model == null) {
                synchronized(pelletpool) {
                    model = pelletpool.getModel();
                }
                try {
                    Thread.sleep(1000);
                } catch(InterruptedException e) {
                }
            }
            //QueryExecution qe = QueryExecutionFactory.create(query, model);
            //ResultSet results = qe.execSelect();
            //ResultSetFormatter.out(System.out, results, query);
            //qe.close();
            doQuery(request, response, model);
            synchronized(pelletpool) {
                pelletpool.freeModel(model);
            }
        }
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if(request.getParameterMap().containsKey("query")) {
            OntModel model = null;
            while(model == null) {
                synchronized(pelletpool) {
                    model = pelletpool.getModel();
                }
                try {
                    Thread.sleep(1000);
                } catch(InterruptedException e) {
                }
            }
            doQuery(request, response, model);
            synchronized(pelletpool) {
                pelletpool.freeModel(model);
            }
        }
    }


	public void doQuery(HttpServletRequest request, HttpServletResponse response, OntModel model) throws ServletException, IOException {
		
		String queryString = request.getParameter("query");
		Query query = QueryFactory.create(queryString);
		
		long startTime = System.currentTimeMillis();
		//Dataset dataset = getDataset(request, query);
		QueryExecution qexec = QueryExecutionFactory.create(query, model) ;
		
		long dataTime = System.currentTimeMillis();
		setContentType(request, response, query);
		if (query.isAskType()) {
			execAsk(request, response, qexec);
		} else if (query.isConstructType()) {
			outputModel(request, response, qexec.execConstruct());
		} else if (query.isDescribeType()) {
			outputModel(request, response, qexec.execDescribe());
		} else if (query.isSelectType()) {
			execSelect(request, response, query, qexec);
		} else {
			response.setStatus(400);
			response.setContentType("text/plain");
			Writer out = response.getWriter();
			out.write("Unknown type for query:\n"+queryString);
		}
       	
		long endTime = System.currentTimeMillis();

		System.out.println("Total time: "+(endTime-startTime));
		System.out.println("Dataset time: "+(dataTime-startTime));
		System.out.println("Query time: "+(endTime-dataTime));
		System.out.println(""+IsCanonical.cacheHits+" cache hits, "+IsCanonical.cacheMisses+" cache misses");
		IsCanonical.cacheHits = 0;
		IsCanonical.cacheMisses = 0;
		
	}
	
	public void execAsk(HttpServletRequest request, HttpServletResponse response, QueryExecution qexec) throws IOException {
		boolean result = qexec.execAsk();
		OutputStream out = response.getOutputStream();
		
		if (request.getParameterMap().containsKey("text")) {
			ResultSetFormatter.out(out, result);
		} else {
			ResultSetFormatter.outputAsXML(out, result);
		}
	}
	
	public void execSelect(HttpServletRequest request, HttpServletResponse response, Query query, QueryExecution qexec) throws IOException {
		ResultSet results = qexec.execSelect() ;

		OutputStream out = response.getOutputStream();
		
		if (request.getParameterMap().containsKey("text")) {
			ResultSetFormatter.out(out, results, query);
		} else {
			ResultSetFormatter.outputAsXML(out, results); 
		};
	}
	public void outputModel(HttpServletRequest request, HttpServletResponse response, Model model) throws IOException {
		OutputStream out = response.getOutputStream();
		model.write(out);
	}

	public void setContentType(HttpServletRequest request, HttpServletResponse response, Query query) throws IOException {
		if (request.getParameterMap().containsKey("text")) {
			response.setContentType("text/plain");
		} else if (query.isAskType() || query.isSelectType()) {
			response.setContentType("application/sparql-results+xml");
		} else if (query.isConstructType() || query.isDescribeType()) {
			response.setContentType("application/rdf+xml");
		}
	}

    public void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader body = request.getReader();
        System.out.println("Got PUT");
        if (request.getParameterMap().containsKey("context")) {
            String context = request.getParameter("context");
            //Model tempmodel = ModelFactory.createDefaultModel();
            OntModel tempmodel = ModelFactory.createOntologyModel( OntModelSpec.OWL_MEM );
            OntDocumentManager docManager = tempmodel.getDocumentManager();
            docManager.addIgnoreImport("http://www.mindswap.org/~katz/ont/Computer.owl" );
            docManager.addIgnoreImport("http://www.mindswap.org/~aditkal/monkey.owl" );
            docManager.addIgnoreImport( "http://xmlns.com/foaf/0.1/" );

            tempmodel.read(body, context);
            synchronized(q) {
                q.add(new Command("PUT", tempmodel, context));
            }
            //contexts.put(context, tempmodel);
            //model.addSubModel(tempmodel);
        } else {
            //model.read(body, "");
        }
    }
    public void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Got DELETE");
        if (request.getParameterMap().containsKey("context")) {
            String context = request.getParameter("context");
            synchronized(q) {
                q.add(new Command("DELETE", null, context));
            }
            //Model tempmodel = (Model)contexts.get(context);
            //model.removeSubModel(tempmodel);
        } else {
            q.add(new Command("RESET", null, null));
            //model = ModelFactory.createOntologyModel(PelletReasonerFactory.THE_SPEC );
        }
    }
}

class Spigot extends Thread {
    Map contexts = null;
    PelletPool pelletpool = null;
    LinkedList q = null;
    String name= "spigot";
    public Spigot(PelletPool pp, LinkedList commands) {
        pelletpool = pp;
        q = commands;
        this.contexts = new HashMap();
        OntModel tempmodel = ModelFactory.createOntologyModel(PelletReasonerFactory.THE_SPEC );
        synchronized(pelletpool) {
            pelletpool.addModel(tempmodel);
        }
    }
    public void run() {
        OntModel model = ModelFactory.createOntologyModel(PelletReasonerFactory.THE_SPEC );
        int size = 0;
        Object peek;
        while(true) {
            synchronized(q) {
                peek = q.peek();
            }
            synchronized(pelletpool) {
                size = pelletpool.size(); 
            }
            while(peek == null && size >= 10) {
                //System.out.println("Looking for commands");
                //synchronized(pelletpool) {
                //    size = pelletpool.size(); 
                //}
                //System.out.println("size =" + size);
                //if(size >= 10) {
                try {
                    //System.out.println("Sleeping .5 seconds");
                    Thread.sleep(500);
                } catch(InterruptedException e) {
                    System.out.println("Got InterruptedException " + e.toString());
                }
                //}
                synchronized(q) {
                    peek = q.peek();
                    //System.out.println("q.size() = " + q.size());
                }
            }
            boolean hadChange = false;
            while(peek != null) {
                //System.out.println("Got a command");
                hadChange = true;
                Command command;
                synchronized(q) {
                    command = (Command)q.remove();
                }
                synchronized(q) {
                    peek = q.peek();
                }
                // do whatever we have to do to the context list
                System.out.println(command);
                if(command.command == "DELETE") {
                    contexts.remove(command.context);
                } else if(command.command == "PUT") {
                    contexts.put(command.context, command.model);
                } else if(command.command == "RESET") {
                    contexts.clear();
                }
            }
            // now need to iterate over the contexts, adding them to the
            // model
            if(hadChange == true){
                //OntModel 
                model = ModelFactory.createOntologyModel(PelletReasonerFactory.THE_SPEC );
                Timers timers = new Timers();
                Timer t;

                System.out.println("Applying changes, creating first model");
                t = timers.startTimer( "adding" );
                Iterator i = contexts.keySet().iterator();
                while(i.hasNext()) {
                    String context = (String)i.next();
                    model.addSubModel((OntModel)contexts.get(context), false);
                }
                t.stop();
                t = timers.startTimer("preparing");
                model.prepare();
                t.stop();
                t = timers.startTimer("rebinding");
                // need to somehow tell the model to inference now
                model.rebind();
                t.stop();
                t = timers.startTimer("consistency");
                System.out.println(((PelletInfGraph) model.getGraph()).getKB().getInfo());
                System.out.println("==============================>" + ((PelletInfGraph) model.getGraph()).getKB().isConsistent());
                if( ((PelletInfGraph)model.getGraph()).getKB().isConsistent() == false ) {
                    Iterator k=contexts.keySet().iterator();
                    while(k.hasNext()) {
                        System.out.println((String)k.next());
                    }
                }
                t.stop();
                KnowledgeBase kb = ((PelletInfGraph) model.getGraph()).getKB();
                t = timers.startTimer("classify");
                kb.classify();
                t.stop();
                t = timers.startTimer("realize");
                kb.realize();
                t.stop();
                
                //OntClass cls = model.getOntClass("http://www.w3.org/2002/07/owl#Thing" );
                //cls.listInstances();
                t = timers.startTimer("pool");
                synchronized(pelletpool) {
                    pelletpool.clear();
                    pelletpool.addModel(model);
                }
                t.stop();
                timers.mainTimer.stop();
                timers.print();
                System.out.println("done creating model");
            } else {
                //int size;
                //synchronized(pelletpool) {
                //    size = pelletpool.size();
                //}
                //if(size < 10) {
                
                //OntModel model = null;
                //while(model == null) {
                //    synchronized(pelletpool) {
                //        model = pelletpool.getModel();
                //    }
                //}
                //System.out.println("Making copy of model");
                //System.out.println("size = " + size);
                KnowledgeBase kb = ((PelletInfGraph) model.getGraph()).getKB();
                OntModelSpec blah;
                KnowledgeBase kb2;
                OntModel model2;
                kb2 = (KnowledgeBase)kb.clone();
                //System.out.println(kb2.getInfo());
                //System.out.println("==============================>" + kb2.isConsistent());
                blah = new OntModelSpec( OntModelSpec.OWL_MEM );
                blah.setReasonerFactory( new PelletReasonerFactory2(kb2));
                model2 = ModelFactory.createOntologyModel( blah);
                Iterator i = contexts.keySet().iterator();
                while(i.hasNext()) {
                    String context = (String)i.next();
                    model2.addSubModel((OntModel)contexts.get(context), false);
                }
                synchronized(pelletpool) {
                    pelletpool.freeModel(model);
                    pelletpool.addModel(model2);
                }
                //System.out.println("done copying");
                //}
            }
        }
    }
}

// 3 possibilities:
// command="PUT", context="<uri>", model=<model>
// command="DELETE", context="<uri>", model=null
// command="RESET", context=null, model=null
class Command {
    public String command;
    public Model model;
    public String context;
    public Command(String cmd, Model m, String con) {
        command = cmd;
        model = m;
        context = con;
    }
    public String toString() {
        return command + " " + context;
    }
}

