package org.mindswap.pellet.servlet;

import java.util.LinkedList;

import org.mindswap.pellet.jena.PelletReasonerFactory;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.ModelFactory;

public class PelletPool {
    protected LinkedList availablemodels;
    protected LinkedList occupiedmodels;
 
    public static void main(String[] args) {
        PelletPool pp = new PelletPool();
        OntModel tempmodel = ModelFactory.createOntologyModel(PelletReasonerFactory.THE_SPEC );
        OntModel tempmodel2 = ModelFactory.createOntologyModel(PelletReasonerFactory.THE_SPEC );
        pp.addModel(tempmodel);
        System.out.println(pp.size());
        pp.addModel(tempmodel2);
        System.out.println(pp.size());
        System.out.println("Hi");
    }
    
    public PelletPool() {
        availablemodels = new LinkedList();
        occupiedmodels = new LinkedList();
    }
    public OntModel getModel() {
        if(availablemodels.size() > 0) {
            OntModel model = (OntModel)availablemodels.removeFirst();
            occupiedmodels.add(model);
            return model;
        }
        return null;
        // move a model from available to occupied
        // what if available is empty???
        // not sure I want to block here, if this isn't thread safe -
        // that could make it impossible to add a model and thus
        // fix the problem.
    }

   public void freeModel(OntModel model) {
        // move a model from occupied to available, if it exists
        // otherwise, do nothing
        if(occupiedmodels.contains(model)) {
            occupiedmodels.remove(model);
            availablemodels.add(model);
        }
    }
    public void addModel(OntModel model) {
        availablemodels.add(model);
    }
    public void clear() {
        availablemodels.clear();
        occupiedmodels.clear();
    }
    public int size() {
        //System.out.println("availablemodels ="+ availablemodels.size());
        //System.out.println("occupiedmodels ="+ occupiedmodels.size());
        return availablemodels.size() + occupiedmodels.size();
    }
}
//public class Spas2 extends HttpServlet {
//    MultiUnion model = null;
//    HashMap contexts = null;
//    public void init(ServletConfig config) {
//        model = new MultiUnion();
//        contexts = new HashMap();
//        //Model model = ModelFactory.createDefaultModel();
//    }
//    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        // still have to write this
//        //OutputStream out = response.getOutputStream();
//        //Model m = ModelFactory.createDefaultModel();
//        //RDFWriter writer = m.getWriter();
//        //writer.write(model, out, "");
//        //model.write(out);
//    }
//    public void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        BufferedReader body = request.getReader();
//        String context = request.getParameter("context");
//        JenaReader jr = new JenaReader();
//        if (request.getParameterMap().containsKey("context")) {
//            //Model tempmodel = ModelFactory.createDefaultModel();
//            Graph tempmodel = new GraphMem();
//            //tempmodel.read(body, context);
//            jr.read(tempmodel, body, context);
//            contexts.put(context, tempmodel);
//            model.addGraph((Graph)tempmodel);
//        } else {
//            //model.read(body, context);
//        }
//    }
//    public void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        if (request.getParameterMap().containsKey("context")) {
//            String context = request.getParameter("context");
//            //Model tempmodel = (Model)contexts.get(context);
//            Graph tempmodel = (Graph)contexts.get(context);
//            model.removeGraph((Graph)tempmodel);
//        } else {
//            //model = new MultiUnion();
//        }
//    }
//}
