/*
 * Created on Oct 20, 2005
 */
package org.mindswap.pellet.taxonomy;


/**
 * @author Evren Sirin
 *
 */
public class ConsoleClassifyProgress implements ClassifyProgress {
    private int curr;
    private int count;
    
    public ConsoleClassifyProgress() {
    }

	public void classificationStarted( int classCount ) {
        curr = 0;
        count = classCount;
        System.out.println( "Classifying " + count + " classes" );
	}
	
	public void realizationStarted( int instanceCount ) {
        curr = 0;
        count = instanceCount;
        System.out.println( "Realizing " + count + " individuals" );
	}

    public void startClass( String uri ) {
        System.out.println( "Classifying (" + ++curr + "/" + count + ") " + uri );
    }

    public void startIndividual( String uri ) {
        System.out.println( "Realizing (" + ++curr + "/" + count + ") " + uri );
    }

    public boolean isCanceled() {
        return false;
    }

    public void taskFinished() {
    }
}
