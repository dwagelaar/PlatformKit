/*
 * Created on Oct 15, 2006
 */
package org.mindswap.pellet.jena.vocabulary;

import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.ResourceFactory;
import com.hp.hpl.jena.vocabulary.OWL;

public class Econn {    
	final public static String NS = OWL.NS;
	
    final public static Resource ForeignOntology = ResourceFactory.createResource( NS + "foreignOntology" );
    final public static Resource ForeignIndividual = ResourceFactory.createResource( NS + "ForeignIndividual" );
    final public static Resource ForeignClass = ResourceFactory.createResource( NS + "ForeignClass" );
    final public static Resource ForeignObjectProperty = ResourceFactory.createResource( NS + "ForeignObjectProperty" );
    final public static Resource ForeignDatatypeProperty = ResourceFactory.createResource( NS + "ForeignDatatypeProperty" );
    final public static Resource ForeignLinkProperty = ResourceFactory.createResource( NS + "ForeignLinkProperty" );
    final public static Resource LinkProperty = ResourceFactory.createResource( NS + "LinkProperty" );
}
