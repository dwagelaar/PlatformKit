/*
 * Created on Aug 29, 2004
 */
package org.mindswap.pellet;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import aterm.ATermAppl;


/**
 * A queue for individuals that need to have completion rules applied
 * 
 * @author Christian Halaschek-Wiener
 */
class CompletionQueue {
	
	static protected int GUESSLIST = 0;
	static protected int NOMLIST = 1;
	static protected int MAXLIST = 2;
	static protected int ALL_CHANGED_LIST = 3;
	static protected int MIN_CHANGED_LIST = 4;
	static protected int ATOMLIST = 5;
	static protected int ORLIST = 6;
	static protected int SOMELIST = 7;
	static protected int MINLIST = 8;
	static protected int SIZE = 9;
	
	
	//current index for individuals that must have a particular rule type applied
	protected int[] typeIndex;

	//The queue - array - each entry is an arraylist for a particular rule type
	protected List[] queue;
	
	
	//pointer to the abox
	protected ABox abox;
	
	

	/**
	 * Create queue
	 * 
	 * @param abox
	 */
	protected CompletionQueue(ABox abox) {
		this.abox = abox;

		//Init
		queue = new ArrayList[SIZE];
		typeIndex = new int[SIZE];
		
		for(int i = 0; i < SIZE; i++){
			queue[i] = new ArrayList();
			typeIndex[i] = 0;
		}
		
	}		

	//Find the next individual in a given queue
	protected void findNext(int type) {
		
		for(; typeIndex[type] < queue[type].size(); typeIndex[type]++) {
		    //Get next node from queue
			Node node = (Node) abox.getNodeMap().get( queue[type].get( typeIndex[type] ) ) ;

			//check that its an individual
		    if( node instanceof Individual ){
			    
		    		//check if its been merged
		    		if( node.isPruned() || node.isMerged() )
		    			node = node.getSame();
		    		
		    		//guarentee that its not still pruned
		    		if(!node.isMerged() && !node.isPruned() && node instanceof Individual)
		    			break;
		    }
			    
		}
	}
	
	
	//Check if there is something else on the queue for a given type
	public boolean hasNext(int type) {
		//find next
		findNext(type);
		
		//check one exits
		if(typeIndex[type] < queue[type].size())
			return true;
		else
			return false;
	}
	
	
	//Reset the queue to be the current nodes in the abox; Also reset the type index to 0
	public void restore() {

		//reset queues - currently do not reset guess list
		for(int i = 0; i < SIZE; i++){
			if(i != this.GUESSLIST)
				queue[i] = new ArrayList(abox.getNodeNames());
			
			typeIndex[i] = 0;
		}
	}
	
	

	//Get the next element of a queue of a given type
	public Object getNext(int type) {
		//get the next index
		findNext(type);
		
		//get the node
		Node ind = (Node) abox.getNodeMap().get( queue[type].get( typeIndex[type]++ ) );
		
		//if its pruned, get the node its merged to
		if( ind.isPruned() || ind.isMerged())
			ind = (Node)ind.getSame();
		
		return ind;
	}

	
	//add an element to the queue
	public void add(ATermAppl x, int type){
			queue[type].add(x);
	}
	
	
	//add an element to the queue
	public void remove(ATermAppl x, int type){
		queue[type].remove(x);
	}

	//remove elements from a queue
	public void removeAll( int type ){
		queue[type].clear();
	}

	//add a list to the queue
	public void addAll(List xs, int type){
		queue[type].addAll(xs);
	}
	
	
	//get all elements of a given queue type
	public List getAll(int type){
		return new ArrayList(queue[type]);
	}

	//reset the current type index
	public void reset(int type){
		typeIndex[type] = 0;
	}
	
}