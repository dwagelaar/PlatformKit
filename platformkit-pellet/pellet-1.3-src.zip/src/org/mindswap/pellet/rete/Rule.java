package org.mindswap.pellet.rete;

import java.util.ArrayList;
import java.util.List;

public class Rule {
	public List lhs, rhs;
	public Rule() {
		lhs = new ArrayList();
		rhs = new ArrayList();
	}

}
