package org.mindswap.pellet.rete;



public interface Term {

	

}
